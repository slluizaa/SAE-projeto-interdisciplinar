﻿using SAE.Models;
using SAE_test.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.DAO
{
    public class DispositivoDAO : PadraoDAO<DispositivoViewModel>
    {
        protected override SqlParameter[] CriaParametros(DispositivoViewModel dispositivo)
        {
            SqlParameter[] parametros = new SqlParameter[3];
            parametros[0] = new SqlParameter("id", dispositivo.Id);
            parametros[1] = new SqlParameter("idlocal", dispositivo.IdLocal);
            parametros[2] = new SqlParameter("nome_dispositivo", dispositivo.NomeDispositivo);
            return parametros;
        }

        protected override DispositivoViewModel MontaModel(DataRow registro)
        {
            DispositivoViewModel d = new DispositivoViewModel();
            d.Id = Convert.ToInt32(registro["id"]);
            d.IdLocal = Convert.ToInt32(registro["idlocal"]);
            d.NomeDispositivo = registro["nome_dispositivo"].ToString();

            return d;
        }
        protected DispositivoViewModel MontaColuna(DataRow registro, string NomeColuna)
        {
            DispositivoViewModel d = new DispositivoViewModel();
            if (NomeColuna.ToUpper() == "IDLOCAL")
            {
                d.IdLocal = Convert.ToInt32(registro["IdLocal"].ToString());
            }

            return d;
        }
        public DispositivoCompletoViewModel MontaModelDispositivoFull(DataRow registro)
        {
            DispositivoCompletoViewModel d = new DispositivoCompletoViewModel();
            d.Id = Convert.ToInt32(registro["Id"]);
            d.NomeDispositivo = registro["Nome_Dispositivo"].ToString();
            d.IdLocal = Convert.ToInt32(registro["IdLocal"]);
            d.NomeLocal = registro["NomeLocal"].ToString();
            d.IdCidade = Convert.ToInt32(registro["IdCidade"]);
            d.NomeCidade = registro["NomeCidade"].ToString();
            d.Estado = registro["Estado"].ToString();
            d.Qtd_Sensores = Convert.ToInt32(registro["Qtd_Sensores"]);

            return d;
        }

        protected override void SetTabela()
        {
            Tabela = "Dispositivos";
        }
        public virtual List<DispositivoViewModel> ListagemAvancadaDispositivo(string nomeDispositivo, string IdLocal)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("nome_dispositivo", nomeDispositivo),
                new SqlParameter("IdLocal", IdLocal)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemAvancada_Dispositivos", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<DispositivoViewModel> lista = new List<DispositivoViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaModel(registro));
                return lista;
            }
        }
        public List<DispositivoViewModel> ListagemCombo(string NomeColuna)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("Tabela", Tabela),
                new SqlParameter("Nome_Coluna", NomeColuna),
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemColuna", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<DispositivoViewModel> lista = new List<DispositivoViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaColuna(registro, NomeColuna));
                return lista;
            }
        }
        public List<DispositivoCompletoViewModel> vwFull_Dispositivos()
        {
            List<DispositivoCompletoViewModel> l=new List<DispositivoCompletoViewModel>();
            string sql = "select * from vwFull_Dispositivos";
            DataTable tabela = new DataTable();
            tabela = HelperDAO.ExecutaSelect(sql, null);
            foreach(DataRow registro in tabela.Rows)
            {
                l.Add(MontaModelDispositivoFull(registro));
            }
            return l;
            

        }
    }
}
