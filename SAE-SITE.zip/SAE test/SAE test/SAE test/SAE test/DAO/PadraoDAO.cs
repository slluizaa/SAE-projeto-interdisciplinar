﻿using SAE.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.DAO
{
    public abstract class PadraoDAO<T> where T : PadraoViewModel
    {
        public PadraoDAO()
        {
            SetTabela();
        }
        protected string Tabela { get; set; }
        protected string NomeSpListagem { get; set; } = "spListagem";
        protected abstract SqlParameter[] CriaParametros(T model);
        protected abstract T MontaModel(DataRow registro);
        protected abstract void SetTabela();
        public virtual void Insert(T model)
        {
            HelperDAO.ExecutaProc("spInsert_" + Tabela, CriaParametros(model));
        }
        public virtual void Update(T model)
        {
            HelperDAO.ExecutaProc("spUpdate_" + Tabela, CriaParametros(model));
        }
        public virtual void Delete(int id)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("id", id),
                new SqlParameter("tabela", Tabela)
            };
            HelperDAO.ExecutaProc("spDelete", p);
        }
        public virtual int ProximoId()
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("tabela", Tabela)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spProximoId", p);
            return Convert.ToInt32(tabela.Rows[0][0]);
        }
        public virtual T Consulta(int id)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("id", id),
                new SqlParameter("tabela", Tabela)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spConsulta", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
                return MontaModel(tabela.Rows[0]);
        }
        public virtual List<T> Listagem(string tabela, string ordem)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("tabela", tabela),
                new SqlParameter("ordem", ordem)
            };
            var returno = HelperDAO.ExecutaProcSelect("spListagem", p);
            if (returno.Rows.Count == 0)
                return null;
            else
            {
                List<T> lista = new List<T>();
                foreach (DataRow registro in returno.Rows)
                    lista.Add(MontaModel(registro));
                return lista;
            }

        }
        /// <summary>
        /// Devolve true se não tiver outro nome igual no banco
        /// </summary>
        /// <param name="NomeColuna"></param>
        /// <param name="NomeEntrada"></param>
        /// <returns>Boolean</returns>
        public Boolean VerificaColuna(string nometabela, string NomeColuna, string NomeEntrada)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("Tabela", nometabela),
                new SqlParameter("Nome_Coluna", NomeColuna),
                new SqlParameter("NomeEntrada", NomeEntrada)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spVerificaColuna", p);
            if (tabela.Rows.Count == 0)
                return true;
            else
                return false;
        }

        public Boolean VerificaNumero(string texto)
        {
            var num = "";

            for (int i = 0; i <= 9; i++)
            {
                num = i.ToString();
                if (texto.IndexOf(num) >= 0)
                    return true;
            }
            return false;
        }

    }
}
