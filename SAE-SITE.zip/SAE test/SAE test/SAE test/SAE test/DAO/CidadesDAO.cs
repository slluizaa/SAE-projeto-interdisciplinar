﻿using SAE.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.DAO
{
    public class CidadesDAO : PadraoDAO<CidadesViewModel>
    {
        protected override SqlParameter[] CriaParametros(CidadesViewModel cidade)
        {
            SqlParameter[] parametros = new SqlParameter[4];
            parametros[0] = new SqlParameter("id", cidade.Id);
            parametros[1] = new SqlParameter("nome", cidade.NomeCidade);
            parametros[2] = new SqlParameter("estado", cidade.Estado);
            parametros[3] = new SqlParameter("pais", cidade.Pais);
            return parametros;
        }

        protected override CidadesViewModel MontaModel(DataRow registro)
        {
            CidadesViewModel c = new CidadesViewModel();
            c.Id = Convert.ToInt32(registro["id"]);
            c.NomeCidade = registro["nome"].ToString();
            c.Estado = registro["estado"].ToString();
            c.Pais = registro["pais"].ToString();

            return c;
        }
        protected CidadesViewModel MontaColuna(DataRow registro, string NomeColuna)
        {
            CidadesViewModel c = new CidadesViewModel();
            if (NomeColuna.ToUpper() == "PAIS")
            {
                c.Pais = registro["pais"].ToString();
            }
            if (NomeColuna.ToUpper() == "ESTADO")
            {
                c.Estado = registro["estado"].ToString();
            }

            return c;
        }
        public virtual List<CidadesViewModel> ListagemAvancadaCidades(string nome, string pais, string estado)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("nome", nome),
                new SqlParameter("estado", estado),
                new SqlParameter("pais", pais)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemAvancada_Cidades", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<CidadesViewModel> lista = new List<CidadesViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaModel(registro));
                return lista;
            }       
        }

        public List<CidadesViewModel> ListagemCombo(string NomeColuna)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("Tabela", Tabela),
                new SqlParameter("Nome_Coluna", NomeColuna),
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemColuna", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<CidadesViewModel> lista = new List<CidadesViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaColuna(registro, NomeColuna));
                return lista;
            }
        }


        protected override void SetTabela()
        {
            Tabela = "Cidades";
        }
    }
}
