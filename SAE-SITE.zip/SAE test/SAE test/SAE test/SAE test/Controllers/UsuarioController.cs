﻿using Microsoft.AspNetCore.Mvc;
using SAE.DAO;
using SAE.Models;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using Microsoft.AspNetCore.Mvc.Filters;

namespace SAE.Controllers
{
    public class UsuarioController : PadraoController<UsuarioViewModel>
    {
        protected UsuarioDAO DAOUsu= new UsuarioDAO();
        public UsuarioController()
        {
            DAO = new UsuarioDAO();
            ExigeAutenticacao = true;

        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            base.OnActionExecuting(context);
        }
        public IActionResult Save(UsuarioViewModel model, string operacao, string tela)
        {
            try
            {
                PreencheDadosParaView(operacao, model);
                ValidaDados(model, operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = operacao;
                    ViewBag.Tela = tela;
                    PreencheDadosParaView(operacao, model);
                    if (ViewBag.Tela == "Cadastro")
                        return View(ViewBag.Tela, model);
                    else
                        return View(ViewBag.Tela, model);
                }
                else
                {
                    if (operacao == "Incluir")
                    {
                        model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        DAO.Insert(model);
                    }
                    else
                    {
                        if (model.FotoPerfil == null)
                        {
                            UsuarioViewModel cid = DAO.Consulta(model.Id);
                            model.FotoPerfilByte = cid.FotoPerfilByte;
                        }
                        else
                        {
                            model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        }
                        DAO.Update(model);
                    }
                    return RedirectToAction(NomeViewIndex);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        public IActionResult SaveTabelaUsuarios(UsuarioViewModel model, string operacao, string tela)
        {
            try
            {
                PreencheDadosParaView(operacao, model);
                ValidaDados(model, operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = operacao;
                    ViewBag.Tela = tela;
                    PreencheDadosParaView(operacao, model);
                    TabelaUsuarios();
                    return View("TabelaUsuarios", model);
                }
                else
                {
                    if (operacao == "Incluir")
                    {
                        model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        DAO.Insert(model);
                    }
                    else
                    {
                        if (model.FotoPerfil == null)
                        {
                            UsuarioViewModel cid = DAO.Consulta(model.Id);
                            model.FotoPerfilByte = cid.FotoPerfilByte;
                        }
                        else
                        {
                            model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        }
                        DAO.Update(model);
                    }
                    return RedirectToAction("TabelaUsuarios");
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        public byte[] ConvertImageToByte(IFormFile file)
        {
            if (file != null)
                using (var ms = new MemoryStream())
                {
                    file.CopyTo(ms);
                    return ms.ToArray();
                }
            else
                return null;
        }
        
        public override IActionResult Delete(int id)
        {
            try
            {

                DAO.Delete(id);
                if (id == Convert.ToInt32(HttpContext.Session.GetString("Id")))
                {
                    HttpContext.Session.Clear();
                    return RedirectToAction("Logoff", "Login");
                }


                return RedirectToAction("TabelaUsuarios");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        protected override void ValidaDados ( UsuarioViewModel model ,string operacao)
        {
            ModelState.Clear();

            #region //Foto
            if (model.FotoPerfil == null && operacao == "Incluir")
                ModelState.AddModelError("FotoPerfil", "Escolha uma imagem.");
            #endregion

            #region //Nome
            if (model.Nome == null)
                ModelState.AddModelError("Nome", "Campo obrigatorio!");
            #endregion

            #region //IdCidade
            if (model.IdCidade <= 0)
                ModelState.AddModelError("IdCidade", "Escolha uma cidade");
            #endregion

            #region //Email
            if (model.Login_ == null)
                ModelState.AddModelError("Login_", "Campo obrigatorio!");
            else if (model.Login_.IndexOf("@") > model.Login_.ToLower().IndexOf(".com"))
                ModelState.AddModelError("Login_", "Deve conter .com depois do @!");
            else if (operacao == "Incluir" && !DAO.VerificaColuna("Usuarios", "Login_", model.Login_))
                ModelState.AddModelError("Login_", "Email indisponivel!");
            #endregion

            #region //Senha
            if (model.Senha == null)
                ModelState.AddModelError("Senha", "Campo obrigatorio!");
            else if (model.Senha.Length < 7 || model.Senha.Length > 14)
                ModelState.AddModelError("Senha", "Deve conte de 7 a 14 caracteres!");
            #endregion

        }
        public IActionResult TabelaUsuarios()
        {
            ViewBag.Tela = "TabelaUsuarios";
            ViewBag.Operacao = "Incluir";
            UsuarioViewModel usuario = new UsuarioViewModel();
            usuario.Id = DAO.ProximoId();
            ExibeConsultaAvancada();
            return View("TabelaUsuarios", usuario);
           
        }
        public IActionResult PerfilEdicao()
        {
            int Id = Convert.ToInt32(HttpContext.Session.GetString("Id"));
            var model = DAO.Consulta(Id);
            return View("PerfilEdicao", model);
        }
        
        
        private void PreparaComboStatusAdmin()
        {
            UsuarioDAO dao = new UsuarioDAO();
            var lista = dao.ListagemCombo("StatusAdmin");
            List<SelectListItem> listaRetorno = new List<SelectListItem>();
            foreach (var StatusAdmin in lista)
                listaRetorno.Add(new SelectListItem(StatusAdmin.StatusAdmin.ToString(), StatusAdmin.Id.ToString()));

            ViewBag.ADM = listaRetorno;
        }
        private void PreparaComboIdCidade()
        {
            UsuarioDAO dao = new UsuarioDAO();
            var lista = dao.ListagemCombo("IdCidade");
            List<SelectListItem> listaRetorno = new List<SelectListItem>();
            foreach (var idCidade in lista)
                listaRetorno.Add(new SelectListItem(idCidade.IdCidade.ToString(), idCidade.Id.ToString()));

            ViewBag.CidadeUsu = listaRetorno;
        }
        public IActionResult ExibeConsultaAvancada()
        {
            try
            {
                PreparaComboStatusAdmin();
                PreparaComboIdCidade();
                ViewBag.ADM.Insert(0, new SelectListItem("TODAS", "0"));
                ViewBag.CidadeUsu.Insert(0, new SelectListItem("TODAS", "0"));
                return null;
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }
        public IActionResult ObtemDadosConsultaAvancada(string Nome, string Login_, string Senha, string IdCidade, string StatusAdmin)
        {
            try
            {
                UsuarioDAO dao = new UsuarioDAO();
                if (string.IsNullOrEmpty(Nome))
                    Nome = "";
                if (string.IsNullOrEmpty(Senha))
                    Senha = "";
                if (string.IsNullOrEmpty(Login_))
                    Login_ = "";
                if (string.IsNullOrEmpty(StatusAdmin))
                    StatusAdmin = "";
                if (string.IsNullOrEmpty(IdCidade))
                    IdCidade = "";
                var lista = dao.ListagemAvancadaUsuario(Login_, Senha , Nome, IdCidade, StatusAdmin);
                return PartialView("pvGridUsuario", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
        public override IActionResult Edit(int id)
        {
            try
            {
                ViewBag.Tela = "PerfilEdicao";
                ViewBag.Operacao = "Alterar";
                var model = DAO.Consulta(id);
                if (model == null)
                    return RedirectToAction(NomeViewIndex);
                else
                {
                    ExibeConsultaAvancada();
                    PreencheDadosParaView("Alterar", model);
                    return View("TabelaUsuarios", model);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

        public IActionResult SaveEdit(UsuarioViewModel model, string operacao, string tela)
        {
            try
            {
                operacao = "Alterar";
                PreencheDadosParaView(operacao, model);
                ValidaDados(model, operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = operacao;
                    ViewBag.Tela = tela;
                    PreencheDadosParaView(operacao, model);
                    return View("PerfilEdicao", model);
                }
                else
                {
                    if (operacao == "Incluir")
                    {
                        model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        DAO.Insert(model);
                    }
                    else
                    {
                        if (model.FotoPerfil == null)
                        {
                            UsuarioViewModel cid = DAO.Consulta(model.Id);
                            model.FotoPerfilByte = cid.FotoPerfilByte;
                        }
                        else
                        {
                            model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        }

                        DAO.Update(model);
                   }
                    return View("PerfilEdicao", model);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }


    }
}
