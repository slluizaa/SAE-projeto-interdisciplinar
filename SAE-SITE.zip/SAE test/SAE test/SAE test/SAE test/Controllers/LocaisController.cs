﻿using SAE.DAO;
using SAE.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SAE.Controllers
{
    public class LocaisController : PadraoController<LocaisViewModel>
    {
        public LocaisController()
        {
            DAO = new LocaisDAO();
            ExigeAutenticacao = true;
        }
        public IActionResult Create()
        {
            ViewBag.Operacao = "Incluir";
            LocaisViewModel locais = new LocaisViewModel();
            locais.Id = DAO.ProximoId();
            ExibeConsultaAvancada();
            return View("Index", locais);
        }
        public IActionResult Save(LocaisViewModel model, string operacao)
        {
            try
            {
                PreencheDadosParaView(operacao, model);
                ValidaDados(model, operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = operacao;
                    PreencheDadosParaView(operacao, model);
                    ExibeConsultaAvancada();
                    return View(NomeViewIndex, model);
                }
                else
                {
                    if (operacao == "Incluir")
                        DAO.Insert(model);
                    else
                        DAO.Update(model);
                    return RedirectToAction(NomeViewIndex, "Home");
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
             public override void OnActionExecuting(ActionExecutingContext context)
             {
              if (ExigeAutenticacao && !HelperController.VerificaUserLogado(HttpContext.Session) || !HelperController.VerificaStatusAdminLogado(HttpContext.Session))
                context.Result = RedirectToAction("Index", "Usuario");
              else
              {
                ViewBag.StatusAdmin = true;
                ViewBag.Logado = true;
                base.OnActionExecuting(context);
              }
             }
        private void PreparaComboIdCidade()
        {
            LocaisDAO dao = new LocaisDAO();
            var lista = dao.ListagemCombo("IdCidade, NomeCidade");
            List<SelectListItem> listaRetorno = new List<SelectListItem>();
            foreach (var row in lista)
                listaRetorno.Add(new SelectListItem(row.IdCidade.ToString() +" - "+ row.NomeCidade, row.Id.ToString()));

            ViewBag.Cidade = listaRetorno;
        }
        public IActionResult ExibeConsultaAvancada()
        {
            try
            {
                PreparaComboIdCidade();
                ViewBag.Cidade.Insert(0, new SelectListItem("-", "0"));
                return null;
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }
        public IActionResult ObtemDadosConsultaAvancada(string nomeLocal, string bairro, string IdCidade)
        {
            try
            {
                LocaisDAO dao = new LocaisDAO();
                if (string.IsNullOrEmpty(nomeLocal))
                    nomeLocal = "";
                if (string.IsNullOrEmpty(bairro))
                    bairro = "";
                if (string.IsNullOrEmpty(IdCidade))
                    IdCidade = "";
                var lista = dao.ListagemAvancadaLocais(nomeLocal, bairro, IdCidade);
                return PartialView("pvGridLocais", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
        public override IActionResult Edit(int id)
        {
            try
            {
                ViewBag.Operacao = "Alterar";
                var model = DAO.Consulta(id);
                if (model == null)
                    return RedirectToAction(NomeViewIndex);
                else
                {
                    ExibeConsultaAvancada();
                    PreencheDadosParaView("Alterar", model);
                    return View(NomeViewIndex, model);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        protected override void ValidaDados(LocaisViewModel model, string operacao)
        {
            ModelState.Clear();
            #region //Id
            if (operacao == "Incluir" && DAO.Consulta(model.Id) != null)
                ModelState.AddModelError("Id", "Código já está em uso!");
            if (operacao == "Alterar" && DAO.Consulta(model.Id) == null)
                ModelState.AddModelError("Id", "Este registro não existe!");
            if (model.Id <= 0)
                ModelState.AddModelError("Id", "Formato Id inválido!");
            #endregion

            #region //Nome da Local
            if (model.NomeLocal == null)
                ModelState.AddModelError("NomeLocal", "Campo obrigatorio!");
            else if (!DAO.VerificaColuna("Locais","NomeLocal", model.NomeLocal))
                ModelState.AddModelError("NomeLocal", "Local ja existe!");
            #endregion

            #region //Nome da Bairro
            if (model.Bairro == null)
                ModelState.AddModelError("Bairro", "Campo obrigatorio!");
            else if (DAO.VerificaNumero(model.Bairro))
                ModelState.AddModelError("Bairro", "Não pode conter numeros!");
            #endregion

            #region //Id Cidade
            if (model.IdCidade <= 0)
                ModelState.AddModelError("IdCidade", "Id de Cidade indisponivel!");
            #endregion
        }

    }
}

