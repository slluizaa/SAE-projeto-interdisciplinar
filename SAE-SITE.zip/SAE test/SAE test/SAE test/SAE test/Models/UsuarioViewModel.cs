﻿using Microsoft.AspNetCore.Http;
using System;

namespace SAE.Models
{
    public class UsuarioViewModel : PadraoViewModel
    {
        public string Login_ { get; set; }
        public string Senha { get; set; }
        public string Nome { get; set; }
        public byte[] FotoPerfilByte { get; set; }
        public IFormFile FotoPerfil { get; set; }
        public string FotoPerfil64
        {
            get
            {
                if (FotoPerfilByte != null)
                    return Convert.ToBase64String(FotoPerfilByte);
                else
                    return string.Empty;
            }
        }
        public string StatusAdmin { get; set; }

        public int IdCidade { get; set; }
    }
}
