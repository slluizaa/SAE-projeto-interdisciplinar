﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.Models
{
    public class LocaisViewModel : PadraoViewModel
    {
        public string NomeLocal { get; set; }
        public string Bairro { get; set; }

        public int IdCidade { get; set; }


        public string NomeCidade { get; set;}
    }
}
