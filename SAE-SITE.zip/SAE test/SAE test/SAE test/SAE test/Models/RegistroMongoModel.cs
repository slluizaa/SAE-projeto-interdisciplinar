﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace MongoDB_SQL_Server.Model
{
    class RegistroMongoModel
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public DateTime recvTime { get; set; }

        [BsonElement]
        public string attrName { get; set; }

        [BsonElement]
        public string attrType { get; set; }

        [BsonElement]
        public string attrValue { get; set; }
    }
}
