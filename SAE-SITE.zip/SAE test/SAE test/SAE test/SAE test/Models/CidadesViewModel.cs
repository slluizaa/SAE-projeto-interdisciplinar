﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.Models
{
    public class CidadesViewModel : PadraoViewModel
    {
        public string NomeCidade { get; set; }
        public string Estado { get; set; }
        public string Pais { get; set; }
    }
}
