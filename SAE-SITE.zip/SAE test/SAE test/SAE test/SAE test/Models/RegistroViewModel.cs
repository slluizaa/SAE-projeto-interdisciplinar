﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAE.Models
{
    public class RegistroViewModel : PadraoViewModel
    {
        public int IdSensor { get; set; }
        public DateTime Data_Reg { get; set; }
        public double Nivel { get; set; }
        public string Chuva { get; set; }
        public string Nivel_De_Alerta { get; set; }

    }
}