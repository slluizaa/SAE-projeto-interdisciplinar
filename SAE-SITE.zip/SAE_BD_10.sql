go
use master
go
go
Drop database SAE
go
go
Create database SAE
go
--^^^^^ Execute antes ^^^^^
----------------------------------------------------------------------------------------------------------------------------------------------------------------


go

--Cria��o das tabelas

use SAE

create table Cidades(
	Id int not null primary key,
	Nome varchar(max),
	Estado varchar(50),
	Pais varchar(50),
	Qtd_Sensores int
)


create table Usuarios(
	Id int not null primary key,
	Login_ varchar(100),
	Senha varchar(50),
	Nome varchar(50),
	Foto_Perfil varbinary(max),
	IdCidade Int,
	StatusAdmin varchar(3),
	constraint FK_Usuarios_IdCidade foreign key (IdCidade) References Cidades(Id) On Delete Set Null
)



create table Locais(
	Id int not null primary key,
	NomeLocal varchar(max),
	Bairro varchar(50),
	IdCidade Int,
	constraint FK_Locais_IdCidade foreign key (IdCidade) References Cidades(Id) On Delete CASCADE
)

create table Dispositivos(
	Id int not null primary key,
	IdLocal Int,
	Nome_Dispositivo varchar(100),
	constraint FK_Dispositivos_IdLocal foreign key (IdLocal) References Locais (Id) On Delete CASCADE
)

create table Registro_Sensores(
	Id int not null primary key,
	IdSensor Int,
	Data_Reg DateTime,
	Nivel decimal(10,2),
	Chuva varchar(10),
	Nivel_De_Alerta varchar(100),
	constraint FK_Registro_Sensores_IdSensor foreign key (IdSensor) References Dispositivos (Id) On Delete CASCADE
)

go

----------------------------------------------------------------------------------------------------------------------------------------------------------------

--Cria��o das Views


go
create view vwFull_Registro_Sensores as
	select R.Id, R.Data_Reg, R.Nivel, R.Chuva, R.Nivel_De_Alerta,
		   D.Id [IdSensor], D.Nome_Dispositivo,
		   L.Id [IdLocal], L.NomeLocal, L.Bairro,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Registro_Sensores R
	left join Dispositivos D on D.Id = R.IdSensor
	left join Locais L on L.Id = D.IdLocal
	left join Cidades C on C.Id = L.IdCidade
go


go
create view vwFull_Dispositivos as
	select D.Id, D.Nome_Dispositivo,
		   L.Id [IdLocal], L.NomeLocal, L.Bairro,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Dispositivos D
	left join Locais L on L.Id = D.IdLocal
	left join Cidades C on C.Id = L.IdCidade
go


go
create view vwFull_Locais as
	select L.Id, L.NomeLocal, L.Bairro,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Locais L
	left join Cidades C on C.Id = L.IdCidade
go


go
create view vwFull_Usuarios as
	select U.Id, U.Login_, U.Senha, U.Nome [NomeUsuario], U.Foto_Perfil, U.StatusAdmin,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Usuarios U
	left join Cidades C on C.Id = U.IdCidade
go

go
create view vwFull_Cidades as
	select * from Cidades
go

----------------------------------------------------------------------------------------------------------------------------------------------------------------

--Cria��o das Stored Procedures
--Insert
go
create procedure spInsert_Cidades (
	@Id int,
	@Nome varchar(max),
	@Estado varchar(50),
	@Pais varchar(50)
) as begin
	insert into Cidades
		(Id, Nome, Estado, Pais, Qtd_Sensores) 
	values 
		(@Id, @Nome, @Estado, @Pais, 0) 
end
go


go
create procedure spInsert_Usuarios (
	@Id int,
	@Login_ varchar(100),
	@Senha varchar(50),
	@Nome varchar(50),
	@Foto_Perfil varbinary(max),
	@IdCidade Int,
	@StatusAdmin varchar(3)
) as begin
	insert into Usuarios
		(Id, Login_, Senha, Nome, Foto_Perfil, IdCidade, StatusAdmin) 
	values 
		(@Id, @Login_, @Senha, @Nome, @Foto_Perfil, @IdCidade, @StatusAdmin) 
end
go


go
create procedure spInsert_Locais (
	@Id int,
	@NomeLocal varchar(max),
	@Bairro varchar(50),
	@IdCidade Int
) as begin
	insert into Locais
		(Id, NomeLocal, Bairro, IdCidade) 
	values 
		(@Id, @NomeLocal, @Bairro, @IdCidade) 
end
go


go
create procedure spInsert_Dispositivos (
	@Id int,
	@IdLocal Int,
	@Nome_Dispositivo varchar(100)
) as begin
	insert into Dispositivos
		(Id, IdLocal, Nome_Dispositivo) 
	values 
		(@Id, @IdLocal, @Nome_Dispositivo) 
end
go


go
create procedure spInsert_Registro_Sensores (
	@Id int,
	@IdSensor Int,
	@Data_Reg DateTime,
	@Nivel decimal(10,2),
	@Chuva varchar(10),
	@Nivel_De_Alerta varchar(100)
) as begin
	insert into Registro_Sensores
		(Id, IdSensor, Data_Reg, Nivel, Chuva, Nivel_De_Alerta) 
	values 
		(@Id, @IdSensor, @Data_Reg, @Nivel, @Chuva, @Nivel_De_Alerta) 
end
go


go
--Update

create procedure spUpdate_Cidades (
	@Id int,
	@Nome varchar(max),
	@Estado varchar(50),
	@Pais varchar(50)
) as begin
	update Cidades set
		Nome = @Nome,
		Estado = @Estado,
		Pais = @Pais
	where Id = @Id
end
go


go
create procedure spUpdate_Usuarios (
	@Id int,
	@Login_ varchar(100),
	@Senha varchar(50),
	@Nome varchar(50),
	@Foto_Perfil varbinary(max),
	@IdCidade Int,
	@StatusAdmin varchar(3)
) as begin
	update Usuarios set
		Login_ = @Login_,
		Senha = @Senha,
		Nome = @Nome,
		Foto_Perfil = @Foto_Perfil,
		IdCidade = @IdCidade,
		StatusAdmin = @StatusAdmin
	where Id = @Id
end
go


go
create procedure spUpdate_Locais (
	@Id int,
	@NomeLocal varchar(max),
	@Bairro varchar(50),
	@IdCidade Int
) as begin
	update Locais set
		Id = @Id,
		NomeLocal = @NomeLocal,
		Bairro = @Bairro,
		IdCidade = @IdCidade
	where Id = @Id
end
go


go
create procedure spUpdate_Dispositivos (
	@Id int,
	@IdLocal Int,
	@Nome_Dispositivo varchar(100)
) as begin
	update Dispositivos set
		IdLocal = @IdLocal,
		Nome_Dispositivo = @Nome_Dispositivo
	where Id = @Id
end
go


go
create procedure spUpdate_Registro_Sensores (
	@Id int,
	@IdSensor Int,
	@Data_Reg DateTime,
	@Nivel decimal(10,2),
	@Chuva varchar(3),
	@Nivel_De_Alerta varchar(100)
) as begin
	update Registro_Sensores set
		IdSensor = @IdSensor,
		Data_Reg = @Data_Reg,
		Nivel = @Nivel,
		Chuva = @Chuva,
		Nivel_De_Alerta = @Nivel_De_Alerta
	where Id = @Id
end
go


go
--Delete
create procedure spDelete (
	@id int,
	@tabela varchar(max)
) as begin
	declare @sql varchar(max)
	set @sql = 'delete ' + @tabela + ' where Id = ' + cast(@id as varchar(max))
	exec(@sql)
end
go

go
--Limpa os registros			Exec spDeleteAllRegistros 
create procedure spDeleteAllRegistros 
as begin
	delete Registro_Sensores 
end
go


go

--Consulta (b�sica e sem ordena��o)
create procedure spConsulta (
	@id int,
	@tabela varchar(max)
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from ' + @tabela + ' where Id = ' + cast(@id as varchar(max))
	exec(@sql)
end
go

go

--select * from vwFull_Registro_Sensores where IdSensor = 1 order by Data_Reg desc
--Consulta (b�sica e sem ordena��o) Exec spConsulta_Ultimo_Registro 1
create procedure spConsulta_Ultimo_Registro (
	@IdSensor int
) as begin
	select top (1) * from vwFull_Registro_Sensores where IdSensor = @IdSensor order by Data_Reg desc
end
go

go

--Consulta (b�sica e sem ordena��o)	Exec spConsultaFull 0, Registro_Sensores
create procedure spConsultaFull (
	@id int,
	@tabela varchar(max)
) as begin
	declare @sql varchar(max)
	if @id = Null or @id <= 0
		set @sql = 'select * from vwFull_' + @tabela 
	else
		set @sql = 'select * from vwFull_' + @tabela + ' where Id = ' + cast(@id as varchar(max))
	print(@sql)
	exec(@sql)
end
go


go

--Listagem (b�sica e com ordena��o)
create procedure spListagem (
	@tabela varchar(max),
	@ordem varchar(max)
) as begin
	if Not @ordem is null
		exec('select * from ' + @tabela + ' order by ' + @ordem)
	else
		exec('select * from ' + @tabela)
end
go


go

--Listagem (b�sica e com ordena��o)		Exec spListagemColuna 'vwFull_Locais', 'IdCidade, NomeCidade'
create procedure spListagemColuna (
	@tabela varchar(max),
	@nome_coluna varchar(max)
) as begin
	exec('select ' + @nome_coluna + ' from ' + @tabela + ' group by ' + @nome_coluna +' order by ' + @nome_coluna)
end
go

go

--Consulta (b�sica e sem ordena��o)	Exec spListagemReg 1
create procedure spListagemReg (
	@IdSensor int
) as begin
	declare @sql varchar(max)
	if @IdSensor = Null or @IdSensor <= 0
		select * from Registro_Sensores
	else
		select * from Registro_Sensores where IdSensor = @IdSensor
end
go

go

--Listagem (b�sica e com ordena��o)		Exec spVerificaColuna 'Usuarios', 'Login_', 'admin@admin.com'
create procedure spVerificaColuna (
	@tabela varchar(max),
	@nome_coluna varchar(max),
	@nomeEntrada varchar(max)
) as begin
	Declare @sql varchar(max)
	Set @sql = ('select ' + @nome_coluna + ' from ' + @tabela + ' where ' + @nome_coluna + ' = ' + CHAR(39) + @nomeEntrada + CHAR(39))
	print (@sql)
	exec (@sql)
end
go

go

--Listagem (b�sica e com ordena��o)		Exec spRetornaId 'Usuarios', 'Login_', 'admin@admin.com'
create procedure spRetornaId (
	@tabela varchar(max),
	@nome_coluna varchar(max),
	@nomeEntrada varchar(max)
) as begin
	Declare @Id int
	Set @Id = ('select Id from ' + @tabela + ' where ' + @nome_coluna + ' = ' + CHAR(39) + @nomeEntrada + CHAR(39))
	return @Id
end
go


go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Cidades '', 'SP', ''
create procedure spListagemAvancada_Cidades (
	@nome varchar(max),
	@estado varchar(50),
	@pais varchar(50)
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Cidades'

	if @nome <> '' or @estado <> '' or @pais <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@nome is null Or @nome = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Nome like ' + CHAR(39) + '%' + @nome + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Nome like ' + CHAR(39) + '%' + @nome + '%' + CHAR(39)
	if Not (@estado is null Or @estado = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Estado = ' + CHAR(39) + @estado + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Estado = ' + CHAR(39) + @estado + CHAR(39)
	if Not (@pais is null Or  @pais = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Pais = ' + CHAR(39) + @pais + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Pais = ' + CHAR(39) + @pais + CHAR(39)
	exec(@sql)
end
go


go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Usuarios '', '', '', 0, ''
create procedure spListagemAvancada_Usuarios (
	@Login_ varchar(max),
	@Senha varchar(max),
	@Nome varchar(max),
	@IdCidade int,
	@StatusAdmin varchar(3)
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Usuarios'

	if @Login_ <> '' or @Senha <> '' or @Nome <> '' or @IdCidade > 0 or @StatusAdmin <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@Login_ is null Or @Login_ = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Login_ like ' + CHAR(39) + '%' + @Login_ + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Login_ like ' + CHAR(39) + '%' + @Login_ + '%' + CHAR(39)

	if Not (@Senha is null Or @Senha = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Senha like ' + CHAR(39) + '%' + @Senha + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Senha like ' + CHAR(39) + '%' + @Senha + '%' + CHAR(39)

	if Not (@Nome is null Or @Nome = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Nome like ' + CHAR(39) + '%' + @Nome + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Nome like ' + CHAR(39) + '%' + @Nome + '%' + CHAR(39)

	if Not (@StatusAdmin is null Or @StatusAdmin = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' StatusAdmin = ' + CHAR(39) + @StatusAdmin + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And StatusAdmin = ' + CHAR(39) +  @StatusAdmin  + CHAR(39)

	if Not (@IdCidade is null Or @IdCidade = 0)
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)

	exec(@sql)
end
go



go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Locais '', '', 1
create procedure spListagemAvancada_Locais (
	@nomeLocal varchar(max),
	@bairro varchar(max),
	@IdCidade int
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Locais'

	if @nomeLocal <> '' or @IdCidade <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@nomeLocal is null Or @nomeLocal = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' NomeLocal like ' + CHAR(39) + '%' + @nomeLocal + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And NomeLocal like ' + CHAR(39) + '%' + @nomeLocal + '%' + CHAR(39)
	if Not (@bairro is null Or @bairro = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Bairro like ' + CHAR(39) + '%' + @bairro + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Bairro like ' + CHAR(39) + '%' + @bairro + '%' + CHAR(39)
	if Not (@IdCidade is null Or @IdCidade = 0)
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)

	exec(@sql)
end
go


go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Dispositivos '', null
create procedure spListagemAvancada_Dispositivos (
	@nome_dispositivo varchar(max),
	@IdLocal int
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Dispositivos'

	if @nome_dispositivo <> '' or @IdLocal <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@nome_dispositivo is null Or @nome_dispositivo = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Nome_Dispositivo like ' + CHAR(39) + '%' + @nome_dispositivo + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Nome_Dispositivo like ' + CHAR(39) + '%' + @nome_dispositivo + '%' + CHAR(39)
	if Not (@IdLocal is null Or @IdLocal = 0)
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' IdLocal = ' + CHAR(39) + Cast(@IdLocal as varchar(max)) + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And IdLocal = ' + CHAR(39) + Cast(@IdLocal as varchar(max)) + CHAR(39)

	exec(@sql)
end
go

go
--Pr�ximo Id
create procedure spProximoId (
	@tabela varchar(max)
) as begin
	exec('select isnull(max(id)+1, 1) as MAIOR from ' + @tabela)
end
go

--Verifica se Login e Senha passados por par�metro, s�o v�lidos
go
create procedure spValidaLogin(
	@Login_ varchar(100),
	@Senha varchar(50)
) as begin
	select * 
	from Usuarios 
	where Login_ = @Login_ And Senha = @Senha
end
go

--Atualiza a quantidade de sensores de todas as cidades (usado exclusivo pelas triggers)
go
create procedure spAtualiza_Qtd_Sensores as begin
	Declare @Qtd int
	Declare @IdCidade int

	declare cursor_cidades cursor forward_only keyset for 
		select Id from Cidades
	
	open cursor_cidades

	fetch next from cursor_cidades
		into @IdCidade

	while (@@FETCH_STATUS = 0)
	begin

		Set @Qtd = (select count(*) from Dispositivos D
						left join Locais L on L.Id = D.IdLocal
						where L.IdCidade = @IdCidade)

		update Cidades Set
			Id = Id,
			Nome = Nome,
			Estado = Estado,
			Pais = Pais,
			Qtd_Sensores = @Qtd
		Where Id = @IdCidade
		

		fetch next from cursor_cidades
			into @IdCidade
	end

	close cursor_cidades

	deallocate cursor_cidades

end
go

--Exec spTempo_x_Nivel 1, null, 'Data_Reg'
go
create procedure spTempo_x_Nivel(
	@IdSensor int,
	@IdLocal int,
	@order_by varchar(max)
) as begin
	
	Declare @sql as varchar(max)
	Set @sql = 'select Data_Reg, Nivel
	from vwFull_Registro_Sensores'

	if not @IdSensor is null begin
		Set @sql = @sql + ' where IdSensor = ' + Cast(@IdSensor as varchar(max))
	end
	else if Not @IdLocal is null begin
		Set @sql = @sql + ' where IdLocal = ' + Cast(@IdLocal as varchar(max))
	end
	if Not @order_by is null begin
		Set @sql = @sql + ' order by ' + @order_by
	end
	else begin
		Set @sql = @sql + ' order by Data_Reg'
	end
	print @sql
	exec(@sql)
end
go

--select * from fncPorcentagem_Chuvas(2, null)
go
create function fncPorcentagem_Chuvas(
	@IdSensor int,
	@IdLocal int
) returns @return table (
	Porcentagem_chovendo decimal(10,2),
	Porcentagem_nao_chovendo decimal(10,2)
) as begin
	Declare @total_chuvas decimal(10,2)
	Declare @chuvas_true decimal(10,2)
	
	if Not @IdSensor is null begin
		Set @total_chuvas = (select count(*) from Registro_Sensores where IdSensor = @IdSensor)
		Set @chuvas_true = (select count(*) from Registro_Sensores where Chuva = 'true' AND IdSensor = @IdSensor)
	end

	else if Not @IdLocal is null begin
		Set @total_chuvas = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where IdLocal = @IdLocal)
		Set @chuvas_true = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where Chuva = 'true' AND IdLocal = @IdLocal)
	end

	if @total_chuvas <= 0
		return

	insert into @return(Porcentagem_chovendo, Porcentagem_nao_chovendo) 
	values(	100 * (@chuvas_true/@total_chuvas),
			100 - 100 * (@chuvas_true/@total_chuvas))

	return
end
go

--select * from fncPorcentagem_Alertas(1, null)
go
create function fncPorcentagem_Alertas(
	@IdSensor int,
	@IdLocal int
) returns @return table (
	Porcentagem_vermelho decimal(10,2),
	Porcentagem_amarelo decimal(10,2),
	Porcentagem_verde decimal(10,2)
) as begin
	Declare @total_alertas decimal(10,2)
	Declare @alertas_vermelho decimal(10,2)
	Declare @alertas_verde decimal(10,2)
	
	if Not @IdSensor is null begin
		Set @total_alertas = (select count(*) from Registro_Sensores where IdSensor = @IdSensor)
		Set @alertas_vermelho = (select count(*) from Registro_Sensores where Nivel_De_Alerta = 'VERMELHO' AND IdSensor = @IdSensor)
		Set @alertas_verde = (select count(*) from Registro_Sensores where Nivel_De_Alerta = 'VERDE' AND IdSensor = @IdSensor)
	end

	else if Not @IdLocal is null begin
		Set @total_alertas = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where IdLocal = @IdLocal)
		Set @alertas_vermelho = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where Nivel_De_Alerta = 'VERMELHO' AND IdLocal = @IdLocal)
		Set @alertas_verde = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where Nivel_De_Alerta = 'VERDE' AND IdLocal = @IdLocal)
	end
	
	if @total_alertas <= 0
		return

	insert into @return(Porcentagem_vermelho, Porcentagem_amarelo, Porcentagem_verde) 
		values(	100*(@alertas_vermelho/@total_alertas),		
				100 - 100 * ( (@alertas_vermelho + @alertas_verde) /@total_alertas),
				100*(@alertas_verde/@total_alertas))

	return
end
go


--Pega a media de nivel
--Compara cada linha se esta acima da m�dia, abaixo ou normal
--Apresenta junto com os outros dados 
go
create function fncMedia_Nivel(
	@IdSensor int,
	@IdLocal int
) returns @return table (
	Id int, 
	Data_Reg DateTime, 
	IdSensor int, 
	NomeLocal varchar(max), 
	NomeCidade varchar(max), 
	Chuva varchar(max), 
	Nivel Decimal(10,2),
	Media Decimal(10,2),
	Relacao_media varchar(max),
	Nivel_De_Alerta varchar(max)
) as begin



	Declare @media_nivel decimal(10,2)
	
	if Not @IdSensor is null begin
		Set @media_nivel = (select AVG(Nivel) from Registro_Sensores where IdSensor = @IdSensor)

		insert into @return (Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta)
		select Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta 
			from vwFull_Registro_Sensores where IdSensor = @IdSensor

	end
	else if Not @IdLocal is null begin
		Set @media_nivel = (select AVG(Nivel) from vwFull_Registro_Sensores where IdLocal = @IdLocal)
		
		insert into @return (Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta)
		select Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta 
			from vwFull_Registro_Sensores where IdLocal = @IdLocal

	end
	else begin
		Set @media_nivel = (select AVG(Nivel) from vwFull_Registro_Sensores)

		insert into @return (Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta)
		select Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta 
			from vwFull_Registro_Sensores

	end
	
	
	Declare cursor_Media_Nivel cursor keyset forward_only for
		select Id from vwFull_Registro_Sensores




	Declare @IdReg int

	open cursor_Media_Nivel

	fetch next from cursor_Media_Nivel
		into @IdReg

	while (@@FETCH_STATUS = 0)
	begin
		Declare @rel_med varchar(20)
		Declare @variacao decimal(10,2)
		Set @variacao = 100*(((select Nivel from Registro_Sensores where Id = @IdReg)-@media_nivel)/@media_nivel)

		update @return set
			Id = Id, 
			Data_Reg = Data_Reg, 
			IdSensor = IdSensor, 
			NomeLocal = NomeLocal, 
			NomeCidade = NomeCidade, 
			Nivel = Nivel, 
			Chuva = Chuva, 
			Nivel_De_Alerta = Nivel_De_Alerta,
			Media = @media_nivel,
			Relacao_media = case 
							when (@variacao < -50) then 'Muito Abaixo da m�dia'
							when (@variacao < -15) then 'Abaixo da m�dia'
							when (@variacao > 15) then 'Acima da m�dia'
							when (@variacao > 50) then 'Muito acima da m�dia'
							else 'Dentro da m�dia' end
		where Id = @IdReg

		fetch next from cursor_Media_Nivel
			into @IdReg
	end

	close cursor_Media_Nivel

	deallocate cursor_Media_Nivel

	
	return


end
go

----------------------------------------------------------------------------------------------------------------------------------------------------------------

--Cria��o das Triggers de Insert
go
create trigger trg_Insert_Usuarios on Usuarios
instead of insert as 
begin

	--Filtro de 1 por vez
	if(select count(*) from Inserted) > 1 begin
		raiserror('N�mero de cadastrados ultrapassou o limite de 1 por vez.',16,1)
		rollback tran
		return
	end

	--Cidade n�o encontrada
	if ( select count(*) from Cidades 
			where Id = (select IdCidade from Inserted)) = 0
	begin
		raiserror('IdCidade n�o existente na tabela de Cidades.',16,1)
		rollback tran
		return
	end

	--Se n�o � ADMin � USU�rio comum
	if ( select StatusAdmin from Inserted ) <> 'ADM' AND (select StatusAdmin from Inserted ) <> 'USU' begin
		raiserror('StatusADM inv�lido.',16,1)
		rollback tran
		return
	end
	
	--Login repetido
	if ( select COUNT(*) from Usuarios u 
			where u.Login_ = (select Login_ from inserted)) > 0 begin
		raiserror('Login j� cadastrado.',16,1)
		rollback tran
		return
	end

	insert into Usuarios select * from inserted
end
go


go
create trigger trg_Insert_Locais on Locais
instead of insert as 
begin
	
	--Filtro de 1 por vez
	if(select count(*) from Inserted) > 1 begin
		raiserror('N�mero de cadastrados ultrapassou o limite de 1 por vez.',16,1)
		rollback tran
		return
	end

	--Cidade n�o encontrada
	if ( select count(*) from Cidades 
			where Id = (select IdCidade from Inserted)) = 0
	begin
		raiserror('IdCidade n�o existente na tabela de Cidades.',16,1)
		rollback tran
		return
	end

	insert into Locais select * from inserted
end
go


go
create trigger trg_Insert_Dispositivos on Dispositivos
instead of insert as 
begin
	
	--Filtro de 1 por vez
	if(select count(*) from Inserted) > 1 begin
		raiserror('N�mero de cadastrados ultrapassou o limite de 1 por vez.',16,1)
		rollback tran
		return
	end

	--Local n�o encontrado
	if ( select count(*) from Cidades 
			where Id = (select IdLocal from Inserted)) = 0
	begin
		raiserror('IdLocal n�o existente na tabela de Locais.',16,1)
		rollback tran
		return
	end

	insert into Dispositivos select * from inserted

	Exec spAtualiza_Qtd_Sensores
end
go


go
create trigger trg_Insert_Registro_Sensores on Registro_Sensores
instead of insert as 
begin
	
	declare cursor_reg cursor static for
		select Id, IdSensor
		from inserted

	declare @Id int
	declare @IdSensor int
	declare @retorno varchar(max)
	Set @retorno = ''

	open cursor_reg

	fetch next from cursor_reg
		into @Id, @IdSensor

	while (@@FETCH_STATUS = 0)
	begin
		
		--Dispositivo n�o encontrado
		if ( select count(*) from Dispositivos
				where Id = (select IdSensor from Inserted where Id = @Id)) = 0
		begin
			Set @retorno = @retorno + 'IdLocal do registro ' + cast((select IdSensor from Inserted where Id = @Id) as varchar(max)) + ' n�o existente na tabela de Locais.' + CHAR(13)+CHAR(10) 
		end
		
		fetch next from cursor_reg
			into @Id, @IdSensor
	end

	close cursor_reg

	deallocate cursor_reg

	if @retorno <> '' begin
		raiserror(@retorno,16,1)
		rollback tran
		return
	end


	insert into Registro_Sensores select * from inserted
end
go


----------------------------------------------------------------------------------------------------------------------------------------------------------------

--Cria��o das Triggers de Update

go
create trigger trg_Update_Usuarios on Usuarios
for update as 
begin

	--Filtro de 1 por vez
	if(select count(*) from Inserted) > 1 begin
		raiserror('N�mero de cadastrados ultrapassou o limite de 1 por vez.',16,1)
		rollback tran
		return
	end

	--Se n�o � ADMin � USU�rio comum
	if ( select StatusAdmin from Inserted ) <> 'ADM' AND (select StatusAdmin from Inserted ) <> 'USU' begin
		raiserror('StatusADM inv�lido.',16,1)
		rollback tran
		return
	end

end
go


go
create trigger trg_Update_Locais on Locais
for update as 
begin
	
	--Filtro de 1 por vez
	if(select count(*) from Inserted) > 1 begin
		raiserror('N�mero de cadastrados ultrapassou o limite de 1 por vez.',16,1)
		rollback tran
		return
	end

	--Cidade n�o encontrada
	if ( select count(*) from Cidades 
			where Id = (select IdCidade from Inserted)) = 0
	begin
		raiserror('IdCidade n�o existente na tabela de Cidades.',16,1)
		rollback tran
		return
	end
end
go


go
create trigger trg_Update_Dispositivos on Dispositivos
for update as 
begin
	
	--Filtro de 1 por vez
	if(select count(*) from Inserted) > 1 begin
		raiserror('N�mero de cadastrados ultrapassou o limite de 1 por vez.',16,1)
		rollback tran
		return
	end

	--Local n�o encontrado
	if ( select count(*) from Locais 
			where Id = (select IdLocal from Inserted)) = 0
	begin
		raiserror('IdLocal n�o existente na tabela de Locais.',16,1)
		rollback tran
		return
	end

	Exec spAtualiza_Qtd_Sensores
end
go


go
create trigger trg_Update_Registro_Sensores on Registro_Sensores
for update as 
begin
	
	declare cursor_reg cursor static for
		select Id, IdSensor
		from inserted

	declare @Id int
	declare @IdSensor int
	declare @retorno varchar(max)
	Set @retorno = ''

	open cursor_reg

	fetch next from cursor_reg
		into @Id, @IdSensor

	while (@@FETCH_STATUS = 0)
	begin
		
		--Dispositivo n�o encontrado
		if ( select count(*) from Dispositivos
				where Id = (select IdSensor from Inserted where Id = @Id)) = 0
		begin
			Set @retorno = @retorno + 'IdLocal do registro ' + cast((select IdSensor from Inserted where Id = @Id) as varchar(max)) + ' n�o existente na tabela de Locais.' + CHAR(13)+CHAR(10) 
		end
		
		fetch next from cursor_reg
			into @Id, @IdSensor
	end

	close cursor_reg

	deallocate cursor_reg

	if @retorno <> '' begin
		Set @retorno = @retorno + 'Lote de inser��o recusado!' 
		raiserror(@retorno,16,1)
		rollback tran
		return
	end
end
go

----------------------------------------------------------------------------------------------------------------------------------------------------------------
--Cria��o de triggers de Delete

go
create trigger trgDelete_Cidades
on Cidades after delete as
begin
	Exec spAtualiza_Qtd_Sensores
end
go

go
create trigger trgDelete_Locais
on Locais after delete as
begin
	Exec spAtualiza_Qtd_Sensores
end
go

go
create trigger trgDelete_Dispositivos
on Dispositivos after delete as
begin
	Exec spAtualiza_Qtd_Sensores
end
go

----------------------------------------------------------------------------------------------------------------------------------------------------------------
--Cria��o de dados de exemplo

go
Exec spInsert_Cidades 1, 'S�o Bernardo do Campo', 'SP', 'Brasil'
Exec spInsert_Cidades 2, 'Mau�', 'SP', 'Brasil'
Exec spInsert_Cidades 3, 'S�o Caetano do Sul', 'SP', 'Brasil'
Exec spInsert_Cidades 4, 'Santo Andr�', 'SP', 'Brasil'
Exec spInsert_Cidades 5, 'Barbacena', 'MG', 'Brasil'

Exec spInsert_Usuarios 1, 'admin@admin.com', 'adm1234', 'ADMIN', null, 5, 'ADM'
Exec spInsert_Usuarios 2, 'usuario', 'Plebeu', 'Cellbit', null, 4, 'USU'

Exec spInsert_Locais 1, 'C�rrego do CEFSA', 'Alvarenga', 1
Exec spInsert_Locais 2, 'C�rrego Itoror�', 'Ribeir�o dos Meninos', 1
Exec spInsert_Locais 3, 'C�rrego Palmares', 'Vila Palmares', 4
Exec spInsert_Locais 4, 'Rio das Mortes', 'Severiano Rezende', 5

Exec spInsert_Dispositivos 1, 1, 'SAE CEFSA Mark 1'
Exec spInsert_Dispositivos 2, 1, 'Dispositivo de teste 2'
Exec spInsert_Dispositivos 3, 3, 'Cabrini Ultron'
Exec spInsert_Dispositivos 4, 2, 'SAE CEFSA Ca�a-Hulk'

Exec spUpdate_Cidades 5, 'Belo Horizonte', 'MG', 'Brasil'
Exec spUpdate_Usuarios 2, 'usuario', 'usu1234', 'Cellbit', null, 4, 'USU'
Exec spUpdate_Locais 4, 'Rio Arrudas', 'Santa Tereza', 5

--Exec spDelete 1, 'Dispositivos'
--Exec spDelete 2, 'Locais'
--Exec spDelete 5, 'Cidades'
go

--select * from Cidades
--select * from Locais
--select * from Dispositivos
--select * from Usuarios

--select * from vwFull_Dispositivos
--select * from vwFull_Registro_Sensores
--Exec spTempo_x_Nivel 1, null, null
--select * from dbo.fncPorcentagem_Chuvas(null,1)
--select * from dbo.fncMedia_Nivel(3,null)