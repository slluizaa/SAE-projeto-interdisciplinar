--Cria��o das Functions


--select * from fncPorcentagem_Chuvas(2, null)
go
create function fncPorcentagem_Chuvas(
	@IdSensor int,
	@IdLocal int
) returns @return table (
	Porcentagem_chovendo decimal(10,2),
	Porcentagem_nao_chovendo decimal(10,2)
) as begin
	Declare @total_chuvas decimal(10,2)
	Declare @chuvas_true decimal(10,2)
	
	if Not @IdSensor is null begin
		Set @total_chuvas = (select count(*) from Registro_Sensores where IdSensor = @IdSensor)
		Set @chuvas_true = (select count(*) from Registro_Sensores where Chuva = 'true' AND IdSensor = @IdSensor)
	end

	else if Not @IdLocal is null begin
		Set @total_chuvas = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where IdLocal = @IdLocal)
		Set @chuvas_true = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where Chuva = 'true' AND IdLocal = @IdLocal)
	end

	if @total_chuvas <= 0
		return

	insert into @return(Porcentagem_chovendo, Porcentagem_nao_chovendo) 
	values(	100 * (@chuvas_true/@total_chuvas),
			100 - 100 * (@chuvas_true/@total_chuvas))

	return
end
go

--select * from fncPorcentagem_Alertas(1, null)
go
create function fncPorcentagem_Alertas(
	@IdSensor int,
	@IdLocal int
) returns @return table (
	Porcentagem_vermelho decimal(10,2),
	Porcentagem_amarelo decimal(10,2),
	Porcentagem_verde decimal(10,2)
) as begin
	Declare @total_alertas decimal(10,2)
	Declare @alertas_vermelho decimal(10,2)
	Declare @alertas_verde decimal(10,2)
	
	if Not @IdSensor is null begin
		Set @total_alertas = (select count(*) from Registro_Sensores where IdSensor = @IdSensor)
		Set @alertas_vermelho = (select count(*) from Registro_Sensores where Nivel_De_Alerta = 'VERMELHO' AND IdSensor = @IdSensor)
		Set @alertas_verde = (select count(*) from Registro_Sensores where Nivel_De_Alerta = 'VERDE' AND IdSensor = @IdSensor)
	end

	else if Not @IdLocal is null begin
		Set @total_alertas = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where IdLocal = @IdLocal)
		Set @alertas_vermelho = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where Nivel_De_Alerta = 'VERMELHO' AND IdLocal = @IdLocal)
		Set @alertas_verde = (select count(*) from Registro_Sensores R
								left join Dispositivos D on D.Id = R.IdSensor
								where Nivel_De_Alerta = 'VERDE' AND IdLocal = @IdLocal)
	end
	
	if @total_alertas <= 0
		return

	insert into @return(Porcentagem_vermelho, Porcentagem_amarelo, Porcentagem_verde) 
		values(	100*(@alertas_vermelho/@total_alertas),		
				100 - 100 * ( (@alertas_vermelho + @alertas_verde) /@total_alertas),
				100*(@alertas_verde/@total_alertas))

	return
end
go


--Pega a media de nivel
--Compara cada linha se esta acima da m�dia, abaixo ou normal
--Apresenta junto com os outros dados 
go
create function fncMedia_Nivel(
	@IdSensor int,
	@IdLocal int
) returns @return table (
	Id int, 
	Data_Reg DateTime, 
	IdSensor int, 
	NomeLocal varchar(max), 
	NomeCidade varchar(max), 
	Chuva varchar(max), 
	Nivel Decimal(10,2),
	Media Decimal(10,2),
	Relacao_media varchar(max),
	Nivel_De_Alerta varchar(max)
) as begin



	Declare @media_nivel decimal(10,2)
	
	if Not @IdSensor is null begin
		Set @media_nivel = (select AVG(Nivel) from Registro_Sensores where IdSensor = @IdSensor)

		insert into @return (Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta)
		select Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta 
			from vwFull_Registro_Sensores where IdSensor = @IdSensor

	end
	else if Not @IdLocal is null begin
		Set @media_nivel = (select AVG(Nivel) from vwFull_Registro_Sensores where IdLocal = @IdLocal)
		
		insert into @return (Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta)
		select Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta 
			from vwFull_Registro_Sensores where IdLocal = @IdLocal

	end
	else begin
		Set @media_nivel = (select AVG(Nivel) from vwFull_Registro_Sensores)

		insert into @return (Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta)
		select Id, Data_Reg, IdSensor, NomeLocal, NomeCidade, Nivel, Chuva, Nivel_De_Alerta 
			from vwFull_Registro_Sensores

	end
	
	
	Declare cursor_Media_Nivel cursor keyset forward_only for
		select Id from vwFull_Registro_Sensores




	Declare @IdReg int

	open cursor_Media_Nivel

	fetch next from cursor_Media_Nivel
		into @IdReg

	while (@@FETCH_STATUS = 0)
	begin
		Declare @rel_med varchar(20)
		Declare @variacao decimal(10,2)
		Set @variacao = 100*(((select Nivel from Registro_Sensores where Id = @IdReg)-@media_nivel)/@media_nivel)

		update @return set
			Id = Id, 
			Data_Reg = Data_Reg, 
			IdSensor = IdSensor, 
			NomeLocal = NomeLocal, 
			NomeCidade = NomeCidade, 
			Nivel = Nivel, 
			Chuva = Chuva, 
			Nivel_De_Alerta = Nivel_De_Alerta,
			Media = @media_nivel,
			Relacao_media = case 
							when (@variacao < -50) then 'Muito Abaixo da m�dia'
							when (@variacao < -15) then 'Abaixo da m�dia'
							when (@variacao > 15) then 'Acima da m�dia'
							when (@variacao > 50) then 'Muito acima da m�dia'
							else 'Dentro da m�dia' end
		where Id = @IdReg

		fetch next from cursor_Media_Nivel
			into @IdReg
	end

	close cursor_Media_Nivel

	deallocate cursor_Media_Nivel

	
	return


end
go