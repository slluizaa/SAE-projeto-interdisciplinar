--Cria��o das Stored Procedures
--Insert
go
create procedure spInsert_Cidades (
	@Id int,
	@Nome varchar(max),
	@Estado varchar(50),
	@Pais varchar(50)
) as begin
	insert into Cidades
		(Id, Nome, Estado, Pais, Qtd_Sensores) 
	values 
		(@Id, @Nome, @Estado, @Pais, 0) 
end
go


go
create procedure spInsert_Usuarios (
	@Id int,
	@Login_ varchar(100),
	@Senha varchar(50),
	@Nome varchar(50),
	@Foto_Perfil varbinary(max),
	@IdCidade Int,
	@StatusAdmin varchar(3)
) as begin
	insert into Usuarios
		(Id, Login_, Senha, Nome, Foto_Perfil, IdCidade, StatusAdmin) 
	values 
		(@Id, @Login_, @Senha, @Nome, @Foto_Perfil, @IdCidade, @StatusAdmin) 
end
go


go
create procedure spInsert_Locais (
	@Id int,
	@NomeLocal varchar(max),
	@Bairro varchar(50),
	@IdCidade Int
) as begin
	insert into Locais
		(Id, NomeLocal, Bairro, IdCidade) 
	values 
		(@Id, @NomeLocal, @Bairro, @IdCidade) 
end
go


go
create procedure spInsert_Dispositivos (
	@Id int,
	@IdLocal Int,
	@Nome_Dispositivo varchar(100)
) as begin
	insert into Dispositivos
		(Id, IdLocal, Nome_Dispositivo) 
	values 
		(@Id, @IdLocal, @Nome_Dispositivo) 
end
go


go
create procedure spInsert_Registro_Sensores (
	@Id int,
	@IdSensor Int,
	@Data_Reg DateTime,
	@Nivel decimal(10,2),
	@Chuva varchar(10),
	@Nivel_De_Alerta varchar(100)
) as begin
	insert into Registro_Sensores
		(Id, IdSensor, Data_Reg, Nivel, Chuva, Nivel_De_Alerta) 
	values 
		(@Id, @IdSensor, @Data_Reg, @Nivel, @Chuva, @Nivel_De_Alerta) 
end
go


go
--Update

create procedure spUpdate_Cidades (
	@Id int,
	@Nome varchar(max),
	@Estado varchar(50),
	@Pais varchar(50)
) as begin
	update Cidades set
		Nome = @Nome,
		Estado = @Estado,
		Pais = @Pais
	where Id = @Id
end
go


go
create procedure spUpdate_Usuarios (
	@Id int,
	@Login_ varchar(100),
	@Senha varchar(50),
	@Nome varchar(50),
	@Foto_Perfil varbinary(max),
	@IdCidade Int,
	@StatusAdmin varchar(3)
) as begin
	update Usuarios set
		Login_ = @Login_,
		Senha = @Senha,
		Nome = @Nome,
		Foto_Perfil = @Foto_Perfil,
		IdCidade = @IdCidade,
		StatusAdmin = @StatusAdmin
	where Id = @Id
end
go


go
create procedure spUpdate_Locais (
	@Id int,
	@NomeLocal varchar(max),
	@Bairro varchar(50),
	@IdCidade Int
) as begin
	update Locais set
		Id = @Id,
		NomeLocal = @NomeLocal,
		Bairro = @Bairro,
		IdCidade = @IdCidade
	where Id = @Id
end
go


go
create procedure spUpdate_Dispositivos (
	@Id int,
	@IdLocal Int,
	@Nome_Dispositivo varchar(100)
) as begin
	update Dispositivos set
		IdLocal = @IdLocal,
		Nome_Dispositivo = @Nome_Dispositivo
	where Id = @Id
end
go


go
create procedure spUpdate_Registro_Sensores (
	@Id int,
	@IdSensor Int,
	@Data_Reg DateTime,
	@Nivel decimal(10,2),
	@Chuva varchar(3),
	@Nivel_De_Alerta varchar(100)
) as begin
	update Registro_Sensores set
		IdSensor = @IdSensor,
		Data_Reg = @Data_Reg,
		Nivel = @Nivel,
		Chuva = @Chuva,
		Nivel_De_Alerta = @Nivel_De_Alerta
	where Id = @Id
end
go


go
--Delete
create procedure spDelete (
	@id int,
	@tabela varchar(max)
) as begin
	declare @sql varchar(max)
	set @sql = 'delete ' + @tabela + ' where Id = ' + cast(@id as varchar(max))
	exec(@sql)
end
go


-------------------------------------------------------------------------------------------------------------------------------------------------------------
--Outras SPs usadas

go
--Limpa os registros			Exec spDeleteAllRegistros 
create procedure spDeleteAllRegistros 
as begin
	delete Registro_Sensores 
end
go


go

--Consulta (b�sica e sem ordena��o)
create procedure spConsulta (
	@id int,
	@tabela varchar(max)
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from ' + @tabela + ' where Id = ' + cast(@id as varchar(max))
	exec(@sql)
end
go

go

--select * from vwFull_Registro_Sensores where IdSensor = 1 order by Data_Reg desc
--Consulta (b�sica e sem ordena��o) Exec spConsulta_Ultimo_Registro 1
create procedure spConsulta_Ultimo_Registro (
	@IdSensor int
) as begin
	select top (1) * from vwFull_Registro_Sensores where IdSensor = @IdSensor order by Data_Reg desc
end
go

go

--Consulta (b�sica e sem ordena��o)	Exec spConsultaFull 0, Registro_Sensores
create procedure spConsultaFull (
	@id int,
	@tabela varchar(max)
) as begin
	declare @sql varchar(max)
	if @id = Null or @id <= 0
		set @sql = 'select * from vwFull_' + @tabela 
	else
		set @sql = 'select * from vwFull_' + @tabela + ' where Id = ' + cast(@id as varchar(max))
	print(@sql)
	exec(@sql)
end
go


go

--Listagem (b�sica e com ordena��o)
create procedure spListagem (
	@tabela varchar(max),
	@ordem varchar(max)
) as begin
	if Not @ordem is null
		exec('select * from ' + @tabela + ' order by ' + @ordem)
	else
		exec('select * from ' + @tabela)
end
go


go

--Listagem (b�sica e com ordena��o)		Exec spListagemColuna 'vwFull_Locais', 'IdCidade, NomeCidade'
create procedure spListagemColuna (
	@tabela varchar(max),
	@nome_coluna varchar(max)
) as begin
	exec('select ' + @nome_coluna + ' from ' + @tabela + ' group by ' + @nome_coluna +' order by ' + @nome_coluna)
end
go

go

--Consulta (b�sica e sem ordena��o)	Exec spListagemReg 1
create procedure spListagemReg (
	@IdSensor int
) as begin
	declare @sql varchar(max)
	if @IdSensor = Null or @IdSensor <= 0
		select * from Registro_Sensores
	else
		select * from Registro_Sensores where IdSensor = @IdSensor
end
go

go

--Listagem (b�sica e com ordena��o)		Exec spVerificaColuna 'Usuarios', 'Login_', 'admin@admin.com'
create procedure spVerificaColuna (
	@tabela varchar(max),
	@nome_coluna varchar(max),
	@nomeEntrada varchar(max)
) as begin
	Declare @sql varchar(max)
	Set @sql = ('select ' + @nome_coluna + ' from ' + @tabela + ' where ' + @nome_coluna + ' = ' + CHAR(39) + @nomeEntrada + CHAR(39))
	print (@sql)
	exec (@sql)
end
go

go

--Listagem (b�sica e com ordena��o)		Exec spRetornaId 'Usuarios', 'Login_', 'admin@admin.com'
create procedure spRetornaId (
	@tabela varchar(max),
	@nome_coluna varchar(max),
	@nomeEntrada varchar(max)
) as begin
	Declare @Id int
	Set @Id = ('select Id from ' + @tabela + ' where ' + @nome_coluna + ' = ' + CHAR(39) + @nomeEntrada + CHAR(39))
	return @Id
end
go


go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Cidades '', 'SP', ''
create procedure spListagemAvancada_Cidades (
	@nome varchar(max),
	@estado varchar(50),
	@pais varchar(50)
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Cidades'

	if @nome <> '' or @estado <> '' or @pais <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@nome is null Or @nome = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Nome like ' + CHAR(39) + '%' + @nome + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Nome like ' + CHAR(39) + '%' + @nome + '%' + CHAR(39)
	if Not (@estado is null Or @estado = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Estado = ' + CHAR(39) + @estado + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Estado = ' + CHAR(39) + @estado + CHAR(39)
	if Not (@pais is null Or  @pais = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Pais = ' + CHAR(39) + @pais + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Pais = ' + CHAR(39) + @pais + CHAR(39)
	exec(@sql)
end
go


go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Usuarios '', '', '', 0, ''
create procedure spListagemAvancada_Usuarios (
	@Login_ varchar(max),
	@Senha varchar(max),
	@Nome varchar(max),
	@IdCidade int,
	@StatusAdmin varchar(3)
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Usuarios'

	if @Login_ <> '' or @Senha <> '' or @Nome <> '' or @IdCidade > 0 or @StatusAdmin <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@Login_ is null Or @Login_ = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Login_ like ' + CHAR(39) + '%' + @Login_ + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Login_ like ' + CHAR(39) + '%' + @Login_ + '%' + CHAR(39)

	if Not (@Senha is null Or @Senha = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Senha like ' + CHAR(39) + '%' + @Senha + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Senha like ' + CHAR(39) + '%' + @Senha + '%' + CHAR(39)

	if Not (@Nome is null Or @Nome = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Nome like ' + CHAR(39) + '%' + @Nome + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Nome like ' + CHAR(39) + '%' + @Nome + '%' + CHAR(39)

	if Not (@StatusAdmin is null Or @StatusAdmin = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' StatusAdmin = ' + CHAR(39) + @StatusAdmin + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And StatusAdmin = ' + CHAR(39) +  @StatusAdmin  + CHAR(39)

	if Not (@IdCidade is null Or @IdCidade = 0)
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)

	exec(@sql)
end
go



go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Locais '', '', 1
create procedure spListagemAvancada_Locais (
	@nomeLocal varchar(max),
	@bairro varchar(max),
	@IdCidade int
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Locais'

	if @nomeLocal <> '' or @IdCidade <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@nomeLocal is null Or @nomeLocal = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' NomeLocal like ' + CHAR(39) + '%' + @nomeLocal + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And NomeLocal like ' + CHAR(39) + '%' + @nomeLocal + '%' + CHAR(39)
	if Not (@bairro is null Or @bairro = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Bairro like ' + CHAR(39) + '%' + @bairro + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Bairro like ' + CHAR(39) + '%' + @bairro + '%' + CHAR(39)
	if Not (@IdCidade is null Or @IdCidade = 0)
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And IdCidade = ' + CHAR(39) + Cast(@IdCidade as varchar(max)) + CHAR(39)

	exec(@sql)
end
go


go

--Consulta (b�sica e sem ordena��o)     Exec spListagemAvancada_Dispositivos '', null
create procedure spListagemAvancada_Dispositivos (
	@nome_dispositivo varchar(max),
	@IdLocal int
) as begin
	declare @sql varchar(max)
	set @sql = 'select * from Dispositivos'

	if @nome_dispositivo <> '' or @IdLocal <> ''
		Set @sql = @sql + ' where'


	Declare @multi_parameters Bit
	Set @multi_parameters = 0

	if Not (@nome_dispositivo is null Or @nome_dispositivo = '')
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' Nome_Dispositivo like ' + CHAR(39) + '%' + @nome_dispositivo + '%' + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And Nome_Dispositivo like ' + CHAR(39) + '%' + @nome_dispositivo + '%' + CHAR(39)
	if Not (@IdLocal is null Or @IdLocal = 0)
		if @multi_parameters = 0 begin
			Set @sql = @sql + ' IdLocal = ' + CHAR(39) + Cast(@IdLocal as varchar(max)) + CHAR(39)
			Set @multi_parameters = 1
		end
		else			
			Set @sql = @sql + ' And IdLocal = ' + CHAR(39) + Cast(@IdLocal as varchar(max)) + CHAR(39)

	exec(@sql)
end
go

go
--Pr�ximo Id
create procedure spProximoId (
	@tabela varchar(max)
) as begin
	exec('select isnull(max(id)+1, 1) as MAIOR from ' + @tabela)
end
go

--Verifica se Login e Senha passados por par�metro, s�o v�lidos
go
create procedure spValidaLogin(
	@Login_ varchar(100),
	@Senha varchar(50)
) as begin
	select * 
	from Usuarios 
	where Login_ = @Login_ And Senha = @Senha
end
go

--Atualiza a quantidade de sensores de todas as cidades (usado exclusivo pelas triggers)
go
create procedure spAtualiza_Qtd_Sensores as begin
	Declare @Qtd int
	Declare @IdCidade int

	declare cursor_cidades cursor forward_only keyset for 
		select Id from Cidades
	
	open cursor_cidades

	fetch next from cursor_cidades
		into @IdCidade

	while (@@FETCH_STATUS = 0)
	begin

		Set @Qtd = (select count(*) from Dispositivos D
						left join Locais L on L.Id = D.IdLocal
						where L.IdCidade = @IdCidade)

		update Cidades Set
			Id = Id,
			Nome = Nome,
			Estado = Estado,
			Pais = Pais,
			Qtd_Sensores = @Qtd
		Where Id = @IdCidade
		

		fetch next from cursor_cidades
			into @IdCidade
	end

	close cursor_cidades

	deallocate cursor_cidades

end
go

--Exec spTempo_x_Nivel 1, null, 'Data_Reg'
go
create procedure spTempo_x_Nivel(
	@IdSensor int,
	@IdLocal int,
	@order_by varchar(max)
) as begin
	
	Declare @sql as varchar(max)
	Set @sql = 'select Data_Reg, Nivel
	from vwFull_Registro_Sensores'

	if not @IdSensor is null begin
		Set @sql = @sql + ' where IdSensor = ' + Cast(@IdSensor as varchar(max))
	end
	else if Not @IdLocal is null begin
		Set @sql = @sql + ' where IdLocal = ' + Cast(@IdLocal as varchar(max))
	end
	if Not @order_by is null begin
		Set @sql = @sql + ' order by ' + @order_by
	end
	else begin
		Set @sql = @sql + ' order by Data_Reg'
	end
	print @sql
	exec(@sql)
end
go