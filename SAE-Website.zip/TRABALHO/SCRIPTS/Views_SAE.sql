--Cria��o das Views


go
create view vwFull_Registro_Sensores as
	select R.Id, R.Data_Reg, R.Nivel, R.Chuva, R.Nivel_De_Alerta,
		   D.Id [IdSensor], D.Nome_Dispositivo,
		   L.Id [IdLocal], L.NomeLocal, L.Bairro,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Registro_Sensores R
	left join Dispositivos D on D.Id = R.IdSensor
	left join Locais L on L.Id = D.IdLocal
	left join Cidades C on C.Id = L.IdCidade
go


go
create view vwFull_Dispositivos as
	select D.Id, D.Nome_Dispositivo,
		   L.Id [IdLocal], L.NomeLocal, L.Bairro,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Dispositivos D
	left join Locais L on L.Id = D.IdLocal
	left join Cidades C on C.Id = L.IdCidade
go


go
create view vwFull_Locais as
	select L.Id, L.NomeLocal, L.Bairro,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Locais L
	left join Cidades C on C.Id = L.IdCidade
go


go
create view vwFull_Usuarios as
	select U.Id, U.Login_, U.Senha, U.Nome [NomeUsuario], U.Foto_Perfil, U.StatusAdmin,
		   C.Id [IdCidade], C.Nome [NomeCidade], C.Estado, C.Qtd_Sensores
	from Usuarios U
	left join Cidades C on C.Id = U.IdCidade
go

go
create view vwFull_Cidades as
	select * from Cidades
go