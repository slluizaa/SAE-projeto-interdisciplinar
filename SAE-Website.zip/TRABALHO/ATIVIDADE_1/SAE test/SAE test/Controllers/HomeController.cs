﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SAE.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using SAE.DAO;
using SAE_test.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Filters;

namespace SAE.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        protected bool ExigeAutenticacao { get; set; } = true;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        public IActionResult Index()
        {
            ViewBag.StatusAdmin = HelperController.VerificaStatusAdminLogado(HttpContext.Session);
            ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
            PreparaComboDispositivoLocal();
            return View();
        }
        private void PreparaComboDispositivoLocal()
        {
            DispositivoDAO dao = new DispositivoDAO();
            var lista = dao.vwFull_Dispositivos();
            List<SelectListItem> listaRetorno = new List<SelectListItem>();
            foreach (var dispositivo in lista)
                listaRetorno.Add(new SelectListItem(dispositivo.Id.ToString() + " - "+ dispositivo.NomeLocal + " - " + dispositivo.NomeCidade, dispositivo.Id.ToString()));

            ViewBag.ListaDispositivoLocal = listaRetorno;
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult AtualizaMongo()
        {
            RegistroDAO rDAO = new RegistroDAO();
            rDAO.AtualizaSQL();
            return RedirectToAction("Index");
        }
        

        public IActionResult ExibeUltimosRegistros(string DispositivoNome)
        {
            try
            {
                RegistroDAO dao = new RegistroDAO();
                if (string.IsNullOrEmpty(DispositivoNome))
                    DispositivoNome = "";
                int IdSensor = Convert.ToInt32(DispositivoNome.Substring(0, 1));
                var lista = dao.RetornaUltimosRegistros(IdSensor);
                return PartialView("pvGridDashHome", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
        public IActionResult ListaRegistrosLog(string DispositivoNome)
        {
            try
            {
                    RegistroDAO dao = new RegistroDAO();
                    if (string.IsNullOrEmpty(DispositivoNome))
                        DispositivoNome = "";
                    int IdSensor = Convert.ToInt32(DispositivoNome.Substring(0, 1));
                    var lista = dao.ListaRegistros(IdSensor);
                    return PartialView("pvGridTabelaRegistros", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (ExigeAutenticacao && !HelperController.VerificaUserLogado(HttpContext.Session) && !HelperController.VerificaStatusAdminLogado(HttpContext.Session))
                context.Result = RedirectToAction("Index", "Login");
            else
            {
                ViewBag.StatusAdmin = true;
                ViewBag.Logado = true;
                base.OnActionExecuting(context);
            }
        }

        public IActionResult Dashboards()
        {
            ViewBag.StatusAdmin = HelperController.VerificaStatusAdminLogado(HttpContext.Session);
            ViewBag.Logado = HelperController.VerificaUserLogado(HttpContext.Session);
            PreparaComboDispositivoLocal();
            return View();
        }

        public IActionResult graficoNivelTempo(string DispositivoNome)
        {
            try
            {
                DashViewModel modelRetorno = new DashViewModel();
                DashBoardsDAO dao = new DashBoardsDAO();
                if (string.IsNullOrEmpty(DispositivoNome))
                    DispositivoNome = "";
                int IdSensor = Convert.ToInt32(DispositivoNome.Substring(0, 1));

                //Preencheu os dados do gráfico Nivel x Tempo
                var lista = dao.ListaNivelTempo(IdSensor);
                if(lista != null)
                {
                    foreach (var aux in lista)
                    {
                        modelRetorno.NivelConcat += aux.Nivel + "|";
                        modelRetorno.TempoConcat += aux.Data_Reg + "|";
                    }
                }

                
                //Preencheu os dados do Gráfico de chuvas
                var listaStr = dao.ListaChuvas(IdSensor);
                if (listaStr != null)
                {
                    modelRetorno.Chovendo += listaStr[0];
                    modelRetorno.NaoChovendo += listaStr[1];
                }


                //Preencheu os dados do Gráfico de alertas
                var listaStr2 = dao.ListaAlertas(IdSensor);
                if (listaStr2 != null)
                {
                    modelRetorno.Verde += listaStr2[0];
                    modelRetorno.Amarelo += listaStr2[1];
                    modelRetorno.Vermelho += listaStr2[2];
                }

                return PartialView("pvGridDashboard", modelRetorno);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }

        public IActionResult Sobre()
        {
            return View();
        }
    }
}
