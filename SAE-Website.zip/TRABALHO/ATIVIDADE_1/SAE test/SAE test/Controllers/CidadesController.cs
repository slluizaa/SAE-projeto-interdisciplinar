﻿using SAE.DAO;
using SAE.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Data.SqlTypes;

namespace SAE.Controllers
{
    public class CidadesController : PadraoController<CidadesViewModel>
    {
        public CidadesController()
        {
            DAO = new CidadesDAO();
            ExigeAutenticacao = true;

        }
        public IActionResult Save(CidadesViewModel model, string operacao)
        {
            try
            {
                PreencheDadosParaView(operacao, model);
                ValidaDados(model, operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = operacao;
                    PreencheDadosParaView(operacao, model);
                    ExibeConsultaAvancada();
                    return View(NomeViewIndex, model);
                }
                else
                {
                    if (operacao == "Incluir")
                        DAO.Insert(model);
                    else
                        DAO.Update(model);
                    return RedirectToAction(NomeViewIndex, "Home");
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        public IActionResult Create()
        {
            ViewBag.Operacao = "Incluir";
            CidadesViewModel cidade = new CidadesViewModel();
            cidade.Id = DAO.ProximoId();
            ExibeConsultaAvancada();
            return View("Index", cidade);
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (ExigeAutenticacao && !HelperController.VerificaUserLogado(HttpContext.Session) || !HelperController.VerificaStatusAdminLogado(HttpContext.Session))
                context.Result = RedirectToAction("Index", "Login");
            else
            {
                ViewBag.StatusAdmin = true;
                ViewBag.Logado = true;
                base.OnActionExecuting(context);
            }
        }
        public IActionResult ExibeConsultaAvancada()
        {
            try
            {
                PreparaComboPais();
                PreparaComboEstado();
                ViewBag.Pais.Insert(0, new SelectListItem("TODAS", "0"));
                ViewBag.Estado.Insert(0, new SelectListItem("TODAS", "0"));
                return null;
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }
        public IActionResult ObtemDadosConsultaAvancada(string nome, string pais, string estado)
        {
            try
            {
                CidadesDAO dao = new CidadesDAO();
                if (string.IsNullOrEmpty(nome))
                    nome = "";
                if (string.IsNullOrEmpty(pais))
                    pais = "";
                if (string.IsNullOrEmpty(estado))
                    estado = "";
                var lista = dao.ListagemAvancadaCidades(nome, pais, estado);
                return PartialView("pvGridCidades", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
        private void PreparaComboPais()
        {
            CidadesDAO dao = new CidadesDAO();
            var lista = dao.ListagemCombo("pais");
            List<SelectListItem> listaRetorno = new List<SelectListItem>();
            foreach (var pais in lista)
                listaRetorno.Add(new SelectListItem(pais.Pais, pais.Id.ToString()));

            ViewBag.Pais = listaRetorno;
        }
        private void PreparaComboEstado()
        {
            CidadesDAO dao = new CidadesDAO();
            var lista = dao.ListagemCombo("estado");
            List<SelectListItem> listaRetorno = new List<SelectListItem>();
            foreach (var estado in lista)
                listaRetorno.Add(new SelectListItem(estado.Estado, estado.Id.ToString()));

            ViewBag.Estado = listaRetorno;
        }
        public override IActionResult Edit(int id)
        {
            try
            {
                ViewBag.Operacao = "Alterar";
                var model = DAO.Consulta(id);
                if (model == null)
                    return RedirectToAction(NomeViewIndex);
                else
                {
                    ExibeConsultaAvancada();
                    PreencheDadosParaView("Alterar", model);
                    return View(NomeViewIndex, model);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        protected override void ValidaDados(CidadesViewModel model, string operacao)
        {
            ModelState.Clear();
            #region //Id
            if (operacao == "Incluir" && DAO.Consulta(model.Id) != null)
                ModelState.AddModelError("Id", "Código já está em uso!");
            if (operacao == "Alterar" && DAO.Consulta(model.Id) == null)
                ModelState.AddModelError("Id", "Este registro não existe!");
            if (model.Id <= 0)
                ModelState.AddModelError("Id", "Formato Id inválido!");
            #endregion

            #region //Nome da Cidade
            if (model.NomeCidade == null)
                ModelState.AddModelError("NomeCidade", "Campo obrigatorio!");
            else if (DAO.VerificaNumero(model.NomeCidade))
                ModelState.AddModelError("NomeCidade", "Não pode conte numeros!");
            else if (!DAO.VerificaColuna("Cidades","Nome", model.NomeCidade))
                ModelState.AddModelError("NomeCidade", "Cidade ja existe!");
            #endregion

            #region //Estado
            if (model.Estado == null)
                ModelState.AddModelError("Estado", "Deve conter siglas do estado!");
            else if (DAO.VerificaNumero(model.Estado))
                ModelState.AddModelError("Estado", "Não pode conte numeros!");
            else if (model.Estado.Trim().Length != 2)
                ModelState.AddModelError("Estado", "Deve conter apenas siglas do estado!");
            #endregion

            #region //País
            if (model.Pais == null)
                ModelState.AddModelError("Pais", "Campo obrigatorio!");
            else if (DAO.VerificaNumero(model.Pais))
                ModelState.AddModelError("Pais", "Não pode conte numeros!");
            #endregion
        }
    }
}
