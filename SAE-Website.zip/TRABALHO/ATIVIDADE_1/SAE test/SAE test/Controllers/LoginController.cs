﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SAE.Controllers;
using SAE.DAO;
using SAE.Models;
using System;
using System.IO;

namespace SAE_test.Controllers
{
    public class LoginController : PadraoController<UsuarioViewModel>
    {
        protected UsuarioDAO DAOUsu = new UsuarioDAO();
        public LoginController()
        {
            DAO = new UsuarioDAO();
        }
        public IActionResult FazLogin(string Login_, string Senha)
        {
            try
            {
                var tabela = DAOUsu.ConsultaLogin(Login_, Senha);
                if (tabela == null)
                {
                    ModelState.AddModelError("Login_", "Email ou senha invalidos!");
                    return View("Index");
                }
                else
                {
                    UsuarioViewModel u = new UsuarioViewModel();
                    HttpContext.Session.SetString("Logado", "true");
                    HttpContext.Session.SetString("Id", tabela.Id.ToString());
                    HttpContext.Session.SetString("StatusAdmin", tabela.StatusAdmin.ToString());
                    ViewBag.StatusAdmin = HelperController.VerificaStatusAdminLogado(HttpContext.Session);


                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception erro)
            {
                return View("Index");
                //return View("Error", new ErrorViewModel(erro.Message));
            }
        }
        public IActionResult LogOff()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }
        public IActionResult Save(UsuarioViewModel model, string operacao, string tela)
        {
            try
            {
                PreencheDadosParaView(operacao, model);
                ValidaDados(model, operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = operacao;
                    ViewBag.Tela = tela;
                    PreencheDadosParaView(operacao, model);
                    if (ViewBag.Tela == "Cadastro")
                        return View(ViewBag.Tela, model);
                    else
                        return View(ViewBag.Tela, model);
                }
                else
                {
                    if (operacao == "Incluir")
                    {
                        model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        DAO.Insert(model);
                    }
                    else
                    {
                        if (model.FotoPerfil == null)
                        {
                            UsuarioViewModel cid = DAO.Consulta(model.Id);
                            model.FotoPerfilByte = cid.FotoPerfilByte;
                        }
                        else
                        {
                            model.FotoPerfilByte = ConvertImageToByte(model.FotoPerfil);
                        }
                        DAO.Update(model);
                    }
                    return RedirectToAction(NomeViewIndex);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        public byte[] ConvertImageToByte(IFormFile file)
        {
            if (file != null)
                using (var ms = new MemoryStream())
                {
                    file.CopyTo(ms);
                    return ms.ToArray();
                }
            else
                return null;
        }
        public IActionResult Create()
        {
            UsuarioViewModel usuario = new UsuarioViewModel();
            CidadesViewModel cidade = new CidadesViewModel();

            ViewBag.Tela = "Cadastro";
            ViewBag.Operacao = "Incluir";
            ViewBag.StatusAdmin = "USU";
            usuario.StatusAdmin = ViewBag.StatusAdmin;
            return View("Cadastro", usuario);
        }
        protected override void ValidaDados(UsuarioViewModel model, string operacao)
        {
            ModelState.Clear();

            #region //Foto
            if (model.FotoPerfil == null && operacao == "Incluir")
                ModelState.AddModelError("FotoPerfil", "Escolha uma imagem.");
            #endregion

            #region //Nome
            if (model.Nome == null)
                ModelState.AddModelError("Nome", "Campo obrigatorio!");
            #endregion

            #region //IdCidade
            if (model.IdCidade <= 0)
                ModelState.AddModelError("IdCidade", "Escolha uma cidade");
            #endregion

            #region //Email
            if (model.Login_ == null)
                ModelState.AddModelError("Login_", "Campo obrigatorio!");
            else if (model.Login_.IndexOf("@") > model.Login_.ToLower().IndexOf(".com"))
                ModelState.AddModelError("Login_", "Deve conter .com depois do @!");
            else if (operacao == "Incluir" && !DAO.VerificaColuna("Usuarios","Login_", model.Login_))
                ModelState.AddModelError("Login_", "Email indisponivel!");
            #endregion

            #region //Senha
            if (model.Senha == null)
                ModelState.AddModelError("Senha", "Campo obrigatorio!");
            else if (model.Senha.Length <7 || model.Senha.Length > 14)
                ModelState.AddModelError("Senha", "Deve conte de 7 a 14 caracteres!");
            #endregion

        }
    }
}
