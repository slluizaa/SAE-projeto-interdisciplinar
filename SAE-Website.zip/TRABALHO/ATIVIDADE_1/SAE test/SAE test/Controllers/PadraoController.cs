﻿using Microsoft.AspNetCore.Mvc;
using SAE.DAO;
using SAE.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;

namespace SAE.Controllers
{
    public class PadraoController<T> : Controller where T:PadraoViewModel
    {
        protected PadraoDAO<T> DAO { get; set; }
        
        protected string NomeViewIndex { get; set; } = "Index";
        protected bool ExigeAutenticacao { get; set; } = false;

        public object NomeViewForm { get; private set; } = "Cadastro";

        public IActionResult Index()
        {
            ViewBag.StatusAdmin = HelperController.VerificaStatusAdminLogado(HttpContext.Session);
            return View("Index");
        }
        
        public virtual IActionResult Delete(int id)
        {
            try
            {
                DAO.Delete(id);


                return RedirectToAction("Create");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }

        protected virtual void ValidaDados(T model, string operacao)
        {
            ModelState.Clear();
            if (operacao == "Incluir" && DAO.Consulta(model.Id) != null)
                ModelState.AddModelError("Id", "Código já está em uso!");
            if (operacao == "Alterar" && DAO.Consulta(model.Id) == null)
                ModelState.AddModelError("Id", "Este registro não existe!");
            if (model.Id <= 0)
                ModelState.AddModelError("Id", "Formato Id inválido!");

        }
        protected virtual void PreencheDadosParaView(string Operacao, T model)
        {
            if (Operacao == "Incluir")
                model.Id = DAO.ProximoId();
        }
        public virtual IActionResult Edit(int id)
        {
            try
            {
                ViewBag.Operacao = "Alterar";
                var model = DAO.Consulta(id);
                if (model == null)
                    return RedirectToAction(NomeViewIndex);
                else
                {
                    PreencheDadosParaView("Alterar", model);
                    return View(NomeViewIndex, model);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }


    }
}
