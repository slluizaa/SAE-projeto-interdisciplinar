﻿using SAE.DAO;
using SAE.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SAE.Controllers
{
    public class DispositivoController : PadraoController<DispositivoViewModel>
    {
        public DispositivoController()
        {
            DAO = new DispositivoDAO();
            ExigeAutenticacao = true;

        }
        public IActionResult Save(DispositivoViewModel model, string operacao)
        {
            try
            {
                PreencheDadosParaView(operacao, model);
                ValidaDados(model, operacao);
                if (ModelState.IsValid == false)
                {
                    ViewBag.Operacao = operacao;
                    PreencheDadosParaView(operacao, model);
                    ExibeConsultaAvancada();
                    return View(NomeViewIndex, model);
                }
                else
                {
                    if (operacao == "Incluir")
                        DAO.Insert(model);
                    else
                        DAO.Update(model);
                    return RedirectToAction(NomeViewIndex, "Home");
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        public IActionResult Create()
        {
            ViewBag.Operacao = "Incluir";
            DispositivoViewModel dispositivo = new DispositivoViewModel();
            dispositivo.Id = DAO.ProximoId();
            ExibeConsultaAvancada();
            return View("Index", dispositivo);
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (ExigeAutenticacao && !HelperController.VerificaUserLogado(HttpContext.Session) || !HelperController.VerificaStatusAdminLogado(HttpContext.Session))
                context.Result = RedirectToAction("Index", "Login");
            else
            {
                ViewBag.StatusAdmin = true;
                ViewBag.Logado = true;
                base.OnActionExecuting(context);
            }
        }
        private void PreparaComboIdLocal()
        {
            DispositivoDAO dao = new DispositivoDAO();
            var lista = dao.ListagemCombo("IdLocal");
            List<SelectListItem> listaRetorno = new List<SelectListItem>();
            foreach (var idLocal in lista)
                listaRetorno.Add(new SelectListItem(idLocal.IdLocal.ToString(), idLocal.Id.ToString()));

            ViewBag.Local = listaRetorno;
        }
        public IActionResult ExibeConsultaAvancada()
        {
            try
            {
                PreparaComboIdLocal();
                ViewBag.Local.Insert(0, new SelectListItem("TODAS", "0"));
                return null;
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.Message));
            }
        }
        public IActionResult ObtemDadosConsultaAvancada(string nome, string IdLocal)
        {
            try
            {
                DispositivoDAO dao = new DispositivoDAO();
                if (string.IsNullOrEmpty(nome))
                    nome = "";
                if (string.IsNullOrEmpty(IdLocal))
                    IdLocal = "";
                var lista = dao.ListagemAvancadaDispositivo(nome, IdLocal);
                return PartialView("pvGridDispositivo", lista);
            }
            catch (Exception erro)
            {
                return Json(new { erro = true, msg = erro.Message });
            }
        }
        public override IActionResult Edit(int id)
        {
            try
            {
                ViewBag.Operacao = "Alterar";
                var model = DAO.Consulta(id);
                if (model == null)
                    return RedirectToAction(NomeViewIndex);
                else
                {
                    ExibeConsultaAvancada();
                    PreencheDadosParaView("Alterar", model);
                    return View(NomeViewIndex, model);
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        protected override void ValidaDados(DispositivoViewModel model, string operacao)
        {
            ModelState.Clear();
            #region //Id
            if (operacao == "Incluir" && DAO.Consulta(model.Id) != null)
                ModelState.AddModelError("Id", "Código já está em uso!");
            if (operacao == "Alterar" && DAO.Consulta(model.Id) == null)
                ModelState.AddModelError("Id", "Este registro não existe!");
            if (model.Id <= 0)
                ModelState.AddModelError("Id", "Formato Id inválido!");
            #endregion

            #region //Nome do Dispositivo
            if (model.NomeDispositivo == null)
                ModelState.AddModelError("NomeDispositivo", "Campo obrigatorio!");
            else if (!DAO.VerificaColuna("Dispositivos","Nome_Dispositivo", model.NomeDispositivo))
                ModelState.AddModelError("NomeDispositivo", "Nome de Dispositivo ja existe!");
            #endregion

            #region //Id Local
            if (model.IdLocal <= 0)
                ModelState.AddModelError("IdLocal", "Id de Local invalido!");
            #endregion
        }

    }
}
