﻿using SAE.Models;

namespace SAE_test.Models
{
    public class DispositivoCompletoViewModel: PadraoViewModel
    {
        public int IdLocal { get; set; }
        public string NomeDispositivo { get; set; }
        public string NomeLocal{get; set;}
        public string Bairro { get; set; }

        public int IdCidade { get; set; }
        public string NomeCidade { get; set; }
        public string Estado { get; set; }
        public int Qtd_Sensores { get; set; }



    }
}
