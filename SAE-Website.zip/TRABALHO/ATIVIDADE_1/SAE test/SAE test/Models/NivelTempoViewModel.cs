﻿using System;

namespace SAE.Models
{
    public class NivelTempoViewModel
    {
        public string Data_Reg { get; set; }
        public string Nivel { get; set; }
    }
}
