﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.Models
{
    public class DispositivoViewModel : PadraoViewModel
    {
        public int IdLocal { get; set; }
        public string NomeDispositivo { get; set; }
    }
}
