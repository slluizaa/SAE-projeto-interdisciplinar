﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.Models
{
    public class DashViewModel
    {
        public string TempoConcat { get; set; }
        public string NivelConcat { get; set; }
        public string Chovendo { get; set; }
        public string NaoChovendo { get; set; }
        public string Verde { get; set; }
        public string Amarelo { get; set; }
        public string Vermelho { get; set; }

    }
}
