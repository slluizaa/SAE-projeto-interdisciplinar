﻿using MongoDB.Driver;
using MongoDB_SQL_Server.Model;
using SAE.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.DAO
{
    public class RegistroDAO : PadraoDAO<RegistroViewModel>
    {
        public override void Delete(int d)
        {
            var p = new SqlParameter[]
            {        };
            HelperDAO.ExecutaProc("spDeleteAllRegistros", p);
        }
        public static List<RegistroViewModel> PegaRegistrosMongoDB()
        {
            var client = new MongoClient("mongodb://helix:H3l1xNG@54.174.238.244:27000");

            var database = client.GetDatabase("sth_helixiot");

            IMongoCollection<RegistroMongoModel> colecao = database.GetCollection<RegistroMongoModel>("sth_/_urn:ngsi-ld:Sensor:001_Sensor");

            var filtro = Builders<RegistroMongoModel>.Filter.Where(x => x.attrType != "commandStatus");
            List<RegistroMongoModel> registros = colecao.Find<RegistroMongoModel>(filtro).ToList();
            List<RegistroMongoModel> reg = registros.OrderBy(x => x.recvTime).ToList();
            List<RegistroViewModel> registroFinal = new List<RegistroViewModel>();
            int id = 1;

            foreach (var registro in reg)
            {
                if (registro.attrName == "dados")
                {
                    string[] dado = registro.attrValue.Split('|');
                    RegistroViewModel x = new RegistroViewModel();
                    x.Id = id;
                    x.IdSensor = int.Parse(dado[0]);
                    x.Data_Reg = registro.recvTime;
                    x.Nivel = (double.Parse(dado[2]) / 100);
                    x.Chuva = dado[1];
                    x.Nivel_De_Alerta = dado[3];
                    registroFinal.Add(x);
                    id++;
                }
            }

            return registroFinal;
        }

        public void AtualizaSQL()
        {
            Delete(69);

            List<RegistroViewModel> listaReg = PegaRegistrosMongoDB();

            foreach (var row in listaReg)
            {
                Insert(row);
            }
        }

        public RegistroViewModel RetornaUltimosRegistros(int IdSensor)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("IdSensor", IdSensor)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spConsulta_Ultimo_Registro", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                RegistroViewModel linha = new RegistroViewModel();
                foreach (DataRow registro in tabela.Rows)
                    linha = MontaModel(registro);
                return linha;
            }
        }

        public List<RegistroViewModel> ListaRegistros(int IdSensor)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("IdSensor", IdSensor)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemReg", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<RegistroViewModel> lista = new List<RegistroViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaModel(registro));
                return lista;
            }
        }

        protected override SqlParameter[] CriaParametros(RegistroViewModel local)
        {
            SqlParameter[] parametros = new SqlParameter[6];
            parametros[0] = new SqlParameter("Id", local.Id);
            parametros[1] = new SqlParameter("IdSensor", local.IdSensor);
            parametros[2] = new SqlParameter("Data_Reg", local.Data_Reg);
            parametros[3] = new SqlParameter("Nivel", local.Nivel);
            parametros[4] = new SqlParameter("Chuva", local.Chuva);
            parametros[5] = new SqlParameter("Nivel_De_Alerta", local.Nivel_De_Alerta);
            return parametros;
        }

        protected override RegistroViewModel MontaModel(DataRow registro)
        {
            RegistroViewModel r = new RegistroViewModel();
            r.Id = Convert.ToInt32(registro["Id"]);
            r.IdSensor = Convert.ToInt32(registro["IdSensor"]);
            r.Data_Reg = Convert.ToDateTime(registro["Data_Reg"]);
            r.Nivel = Convert.ToDouble(registro["Nivel"]);
            r.Chuva = registro["Chuva"].ToString();
            r.Nivel_De_Alerta = registro["Nivel_De_Alerta"].ToString();

            return r;
        }

        protected override void SetTabela()
        {
            Tabela = "Registro_Sensores";
        }
    }


}
