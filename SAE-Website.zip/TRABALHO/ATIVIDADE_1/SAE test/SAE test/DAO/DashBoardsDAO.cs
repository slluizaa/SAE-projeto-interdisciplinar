﻿using MongoDB.Driver;
using MongoDB_SQL_Server.Model;
using SAE.Models;
using SAE_test.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.DAO
{
    public class DashBoardsDAO
    {
        public NivelTempoViewModel MontaModelNivelTempo(DataRow registro)
        {
            NivelTempoViewModel nt = new NivelTempoViewModel();
            if (registro["Data_Reg"] == null)
                nt.Data_Reg = "";
            else
                nt.Data_Reg = registro["Data_Reg"].ToString();

            if (registro["Nivel"] == null)
                nt.Nivel = "";
            else
                nt.Nivel = registro["Nivel"].ToString();

            return nt;
        }

        public List<NivelTempoViewModel> ListaNivelTempo(int IdSensor)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("IdSensor", IdSensor),
                new SqlParameter("IdLocal", DBNull.Value),
                new SqlParameter("order_by", "Data_Reg")
            };
            var returno = HelperDAO.ExecutaProcSelect("spTempo_x_Nivel", p);
            if (returno.Rows.Count == 0)
                return null;
            else
            {
                List<NivelTempoViewModel> lista = new List<NivelTempoViewModel>();
                foreach (DataRow registro in returno.Rows)
                    lista.Add(MontaModelNivelTempo(registro));
                return lista;
            }

        }

        public List<string> ListaChuvas(int IdSensor)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("IdSensor", IdSensor),
                new SqlParameter("IdLocal", DBNull.Value)
            };
            var returno = HelperDAO.ExecutaSelect($"select * from fncPorcentagem_Chuvas({IdSensor.ToString()}, null)", null);
            if (returno.Rows.Count == 0)
                return null;
            else
            {
                List<string> lista = new List<string>();
                foreach (DataRow registro in returno.Rows)
                {
                    lista.Add(registro["Porcentagem_chovendo"].ToString());
                    lista.Add(registro["Porcentagem_nao_chovendo"].ToString());
                }
                return lista;
            }
        }

        public List<string> ListaAlertas(int IdSensor)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("IdSensor", IdSensor),
                new SqlParameter("IdLocal", DBNull.Value)
            };
            var returno = HelperDAO.ExecutaSelect($"select * from fncPorcentagem_Alertas({IdSensor.ToString()}, null)", null);
            if (returno.Rows.Count == 0)
                return null;
            else
            {
                List<string> lista = new List<string>();
                foreach (DataRow registro in returno.Rows)
                {
                    lista.Add(registro["Porcentagem_vermelho"].ToString());
                    lista.Add(registro["Porcentagem_amarelo"].ToString());
                    lista.Add(registro["Porcentagem_verde"].ToString());
                }
                return lista;
            }
        }
    }
}
