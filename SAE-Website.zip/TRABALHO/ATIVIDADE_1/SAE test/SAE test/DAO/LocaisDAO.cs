﻿using SAE.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SAE.DAO
{
    public class LocaisDAO : PadraoDAO<LocaisViewModel>
    {
        protected override SqlParameter[] CriaParametros(LocaisViewModel local)
        {
            SqlParameter[] parametros = new SqlParameter[4];
            parametros[0] = new SqlParameter("id", local.Id);
            parametros[1] = new SqlParameter("nomelocal", local.NomeLocal);
            parametros[2] = new SqlParameter("bairro", local.Bairro);
            parametros[3] = new SqlParameter("idcidade", local.IdCidade);
            return parametros;
        }

        protected override LocaisViewModel MontaModel(DataRow registro)
        {
            LocaisViewModel l = new LocaisViewModel();
            l.Id = Convert.ToInt32(registro["id"]);
            l.NomeLocal = registro["nomelocal"].ToString();
            l.Bairro = registro["bairro"].ToString();
            l.IdCidade = Convert.ToInt32(registro["idcidade"]);

            return l;
        }
        protected LocaisViewModel MontaColuna(DataRow registro, string NomeColuna)
        {
            LocaisViewModel d = new LocaisViewModel();
            if (NomeColuna.ToUpper() == "IDCIDADE")
            {
                d.IdCidade = Convert.ToInt32(registro["IdCidade"].ToString());
            }

            return d;
        }
        protected LocaisViewModel MontaColunaCombo(DataRow registro, string NomeColuna)
        {
            LocaisViewModel d = new LocaisViewModel();
            if (NomeColuna.ToUpper() == "IDCIDADE, NOMECIDADE")
            {
                d.IdCidade = Convert.ToInt32(registro["IdCidade"].ToString());
                d.NomeCidade = registro["NomeCidade"].ToString();
            }

            return d;
        }

        protected override void SetTabela()
        {
            Tabela = "Locais";
        }
        public virtual List<LocaisViewModel> ListagemAvancadaLocais(string nomeLocal, string bairro, string IdCidade)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("nomeLocal", nomeLocal),
                new SqlParameter("bairro", bairro),
                new SqlParameter("IdCidade", IdCidade)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemAvancada_Locais", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<LocaisViewModel> lista = new List<LocaisViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaModel(registro));
                return lista;
            }
        }
        public List<LocaisViewModel> ListagemCombo(string NomeColuna)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("Tabela", "vwFull_" + Tabela),
                new SqlParameter("Nome_Coluna", NomeColuna),
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemColuna", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<LocaisViewModel> lista = new List<LocaisViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaColunaCombo(registro, NomeColuna));
                return lista;
            }
        }
    }
}
