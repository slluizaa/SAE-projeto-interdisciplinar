﻿using SAE.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace SAE.DAO
{
    public class UsuarioDAO : PadraoDAO<UsuarioViewModel>
    {

        protected override SqlParameter[] CriaParametros(UsuarioViewModel usuario)
        {
            object imgByte = usuario.FotoPerfilByte;
            if (imgByte == null)
                imgByte = DBNull.Value;
            SqlParameter[] parametros = new SqlParameter[7];
            parametros[0] = new SqlParameter("id", usuario.Id);
            parametros[1] = new SqlParameter("login_", usuario.Login_);
            parametros[2] = new SqlParameter("senha", usuario.Senha);
            parametros[3] = new SqlParameter("nome", usuario.Nome);
            parametros[4] = new SqlParameter("foto_Perfil", imgByte);
            parametros[5] = new SqlParameter("IdCidade", usuario.IdCidade);
            parametros[6] = new SqlParameter("statusadmin", usuario.StatusAdmin);
            return parametros;
        }

        protected override UsuarioViewModel MontaModel(DataRow registro)
        {
            UsuarioViewModel u = new UsuarioViewModel();
            u.Id = Convert.ToInt32(registro["id"]);
            u.Login_ = registro["login_"].ToString();
            u.Senha = registro["senha"].ToString();
            u.Nome = registro["nome"].ToString();

            if(registro["foto_perfil"] != DBNull.Value)
                u.FotoPerfilByte = registro["foto_perfil"] as byte[];
            if (registro["IdCidade"] == DBNull.Value)
            {
                u.IdCidade = 0;
            }
            else
            {
                u.IdCidade = Convert.ToInt32(registro["IdCidade"]);
            }
            u.StatusAdmin = registro["statusadmin"].ToString();

            return u;
        }
        public UsuarioViewModel ConsultaLogin(string Login_, string Senha)
        {
            var l = new SqlParameter[]
            {
                new SqlParameter("Login_", Login_),
                new SqlParameter("Senha", Senha)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spValidaLogin", l);
            if (tabela.Rows.Count == 0)
                return null;
            else
                return MontaModel(tabela.Rows[0]);
        }
        protected UsuarioViewModel MontaColuna(DataRow registro, string NomeColuna)
        {
            UsuarioViewModel u = new UsuarioViewModel();
            if (NomeColuna.ToUpper() == "STATUSADMIN")
            {
                u.StatusAdmin =registro["StatusAdmin"].ToString();
            }
            if (NomeColuna.ToUpper() == "IDCIDADE")
            {
                u.IdCidade = Convert.ToInt32(registro["IdCidade"].ToString());
            }

            return u;
        }

        protected override void SetTabela()
        {
            Tabela = "Usuarios";
        }
        public List<UsuarioViewModel> ListagemCombo(string NomeColuna)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("Tabela", Tabela),
                new SqlParameter("Nome_Coluna", NomeColuna),
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemColuna", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<UsuarioViewModel> lista = new List<UsuarioViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaColuna(registro, NomeColuna));
                return lista;
            }
        }
        public virtual List<UsuarioViewModel> ListagemAvancadaUsuario(string Login_, string Senha, string Nome, string IdCidade, string StatusAdmin)
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("Login_", Login_),
                new SqlParameter("Senha", Senha),
                new SqlParameter("Nome", Nome),
                new SqlParameter("IdCidade", IdCidade),
                new SqlParameter("StatusAdmin", StatusAdmin)
            };
            var tabela = HelperDAO.ExecutaProcSelect("spListagemAvancada_Usuarios", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
            {
                List<UsuarioViewModel> lista = new List<UsuarioViewModel>();
                foreach (DataRow registro in tabela.Rows)
                    lista.Add(MontaModel(registro));
                return lista;
            }
        }
    }
}
