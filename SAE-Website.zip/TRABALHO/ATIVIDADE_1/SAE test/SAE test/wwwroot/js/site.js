﻿function exibirImagem() {
    var oFReader = new FileReader();
    oFReader.readAsDataURL(document.getElementById("Imagem").files[0]);
    oFReader.onload = function (oFREvent) {
        document.getElementById("imgPreview").src = oFREvent.target.result;
    };
}

function aplicaFiltroConsultaAvancadaCidades() {
    var vNome = document.getElementById('nome').value;
    var dropdownPais = document.getElementById('pais');
    var vPais = dropdownPais.options[dropdownPais.selectedIndex].text;
    var dropdownNome = document.getElementById('estado');
    var vEstado = dropdownNome.options[dropdownNome.selectedIndex].text;
    if (vPais == "TODAS") {
        vPais = ""
    }
    if (vEstado == "TODAS") {
        vEstado = ""
    }
    $.ajax({
        url: "/cidades/ObtemDadosConsultaAvancada",
        data: { nome : vNome, pais: vPais, estado: vEstado},
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            }
            else {
                document.getElementById('resultadoConsulta').innerHTML = dados;
            }
        },
    });
}

function aplicaFiltroConsultaAvancadaDispositivos() {
    var vNome = document.getElementById('Nome_Dispositivo').value;
    var dropdownIdLocal = document.getElementById('idLocal');
    var vIdLocal = dropdownIdLocal.options[dropdownIdLocal.selectedIndex].text;
    if (vIdLocal == "TODAS") {
        vIdLocal = ""
    }
    $.ajax({
        url: "/dispositivo/ObtemDadosConsultaAvancada",
        data: { nome: vNome, IdLocal: vIdLocal },
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            }
            else {
                document.getElementById('resultadoConsulta').innerHTML = dados;
            }
        },
    });
}


function aplicaFiltroConsultaAvancadaLocais() {    
    var vNomeLocal = document.getElementById('NomeLocal').value;
    var vBairro = document.getElementById('bairro').value;
    var dropdownIdCidade = document.getElementById('IdCidade');
    var vIdCidade = dropdownIdCidade.options[dropdownIdCidade.selectedIndex].text;
    if (vIdCidade == "TODAS") {
        vIdCidade = ""
    }
    else {
        vIdCidade = vIdCidade[0]
    }
    $.ajax({
        url: "/locais/ObtemDadosConsultaAvancada",
        data: { nomeLocal: vNomeLocal, bairro: vBairro, IdCidade: vIdCidade },
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            }
            else {
                document.getElementById('resultadoConsulta').innerHTML = dados;
            }
        },
    });
}

function aplicaFiltroHome() {
    var dropdownListaDispositivo = document.getElementById('ListaDispositivo');
    var vListaDispositivo = dropdownListaDispositivo.options[dropdownListaDispositivo.selectedIndex].text;
    if (vListaDispositivo == "TODAS") {
        vListaDispositivo = ""
    } 
    $.ajax({
        url: "/home/ExibeUltimosRegistros",
        data: { DispositivoNome: vListaDispositivo },
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            }
            else {
                document.getElementById('resultadoConsultaUltimos').innerHTML = dados;
            }
        },
    });
}

function listaRegistros() {
    var dropdownListaDispositivo = document.getElementById('ListaDispositivo');
    var vListaDispositivo = dropdownListaDispositivo.options[dropdownListaDispositivo.selectedIndex].text;
    if (vListaDispositivo == "TODAS") {
        vListaDispositivo = ""
    } 
    $.ajax({
        url: "/home/ListaRegistrosLog",
        data: { DispositivoNome: vListaDispositivo },
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            }
            else {
                document.getElementById('resultadoConsultaTabela').innerHTML = dados;
            }
        },
    });
}

function aplicaFiltroConsultaAvancadaUsuario() {
    var vNome = document.getElementById('nome').value;
    var vLogin = document.getElementById('login_').value;
    var vSenha = document.getElementById('senha').value;
    var dropdownIdCidade = document.getElementById('IdCidade');
    var vIdCidade = dropdownIdCidade.options[dropdownIdCidade.selectedIndex].text;
    var dropdownStatusAdmin = document.getElementById('StatusAdmin');
    var vStatusAdmin = dropdownStatusAdmin.options[dropdownStatusAdmin.selectedIndex].text;
    if (vIdCidade == "TODAS") {
        vIdCidade = ""
    }
    if (vStatusAdmin == "TODAS") {
        vStatusAdmin = ""
    }
    $.ajax({
        url: "/usuario/ObtemDadosConsultaAvancada",
        data: { Nome: vNome, Login_: vLogin, Senha: vSenha, IdCidade: vIdCidade, StatusAdmin: vStatusAdmin},
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            }
            else {
                document.getElementById('resultadoConsulta').innerHTML = dados;
            }
        },
    });
}

function criaGraficoNivelTempo() {
    var dropdownListaDispositivo = document.getElementById('ListaDispositivo');
    var vListaDispositivo = dropdownListaDispositivo.options[dropdownListaDispositivo.selectedIndex].text;
    if (vListaDispositivo == "TODAS") {
        vListaDispositivo = ""
    }
    $.ajax({
        url: "/home/graficoNivelTempo",
        data: { DispositivoNome: vListaDispositivo },
        success: function (dados) {
            if (dados.erro != undefined) {
                alert(dados.msg);
            }
            else {
                document.getElementById('resultadoConsultaNivelTempo').innerHTML = dados;
            }
        },
    });
}

function GeraGraficos(Nivel, Tempo, Chovendo, NaoChovendo, Verde, Amarelo, Vermelho) {
    graficoNivelTempo(Nivel, Tempo);
    graficoChuvas(Chovendo, NaoChovendo)
    graficoAlertas(Verde, Amarelo, Vermelho)
}

function graficoNivelTempo(Nivel, Tempo) {
    Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#292b2c';

    // Area Chart Example
    var ctx = document.getElementById("NivelxTempo");
    const strVetorNivel = Nivel.split('|');
    const vLabels = Tempo.split('|');

    var vLabels1 = [];
    for (var i = parseInt((vLabels.length)*0.75); i < vLabels.length; i++) {
        vLabels1.push(vLabels[i]);
    }
    console.log(vLabels1)
    var vValues = [];
    for (var i = parseInt((strVetorNivel.length)*0.75); i < strVetorNivel.length; i++) {
        vValues.push(parseFloat(strVetorNivel[i]));
    }
    console.log(parseInt((strVetorNivel.length) / (3 / 4)))

    console.log(vLabels);
    var myLineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: vLabels1,
            datasets: [{
                label: "Sessions",
                lineTension: 0.3,
                backgroundColor: "rgba(2,117,216,0.2)",
                borderColor: "rgba(2,117,216,1)",
                pointRadius: 5,
                pointBackgroundColor: "'#023047'",
                pointBorderColor: "#8ecae6",
                pointHoverRadius: 5,
                pointHoverBackgroundColor: "rgba(2,117,216,1)",
                pointHitRadius: 50,
                pointBorderWidth: 2,
                pointStyle: 'line',
                data: vValues,
            }],
        },
        options: {
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false
                    },
                    ticks: {
                        autoSkip: true,
                        maxTicksLimit: 20
                        
                    }
                }],
                yAxes: [{
                    ticks: {
                        min: 0,
                        max: 50,
                        maxTicksLimit: 5
                    },
                    gridLines: {
                        color: "rgba(0, 0, 0, .125)",
                    }
                }],
            },
            legend: {
                display: false
            }
        }
    });
}

function graficoChuvas(Chovendo, NaoChovendo) {
    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#292b2c';


    var vChovendo = Chovendo.replace(',', '.');
    var vNaoChovendo = NaoChovendo.replace(',', '.'); 
    vChovendo = parseFloat(vChovendo);
    vNaoChovendo = parseFloat(vNaoChovendo);


    // Pie Chart Example
    var ctx = document.getElementById("porcentagemChuva");
    vChovendo = parseFloat(Chovendo);
    vNaoChovendo = parseFloat(NaoChovendo);
    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ["Chovendo", "Não chovendo"],
            datasets: [{
                data: [vChovendo, vNaoChovendo],
                backgroundColor: ['#023047', '#8ecae6'],
            }],
        },
    });
}

function graficoAlertas(Verde, Amarelo, Vermelho) {
    // Set new default font family and font color to mimic Bootstrap's default styling
    // Set new default font family and font color to mimic Bootstrap's default styling
    Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
    Chart.defaults.global.defaultFontColor = '#858796';

    var vVerde = Verde.replace(',', '.');
    var vAmarelo = Amarelo.replace(',', '.');
    var vVermelho = Vermelho.replace(',', '.');

    vVerde = parseFloat(vVerde);
    vAmarelo = parseFloat(vAmarelo);
    vVermelho = parseFloat(vVermelho);

    // Pie Chart Example

    var ctx = document.getElementById("porcentagemAlertas");
    var myPieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ["Verde", "Amarelo", "Vermelho"],
            datasets: [{
                data: [vVerde, vAmarelo, vVermelho],
                backgroundColor: ['#2b9348', '#ffee32', '#ba181b'],
            }],
        },
    });
}